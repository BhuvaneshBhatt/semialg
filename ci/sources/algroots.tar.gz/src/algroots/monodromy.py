"""Monodromy loops and orbit discovery built on reusable path tracking."""

from __future__ import annotations

import math
import multiprocessing
import random
from collections.abc import Iterable, Sequence
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass, replace
from typing import TYPE_CHECKING, Any

import mpmath as mp
import sympy as sp

if TYPE_CHECKING:
    from .recognition import RecognizedSystemRoot

from ._validation import validate_recognition_options
from .algebraic import _AlgebraicProjector, _project_candidates
from .algebraization import AlgebraizedSystem, algebraize_system
from .continuation import (
    PathResult,
    PathTrackerOptions,
    SympyHomotopy,
    _relative_residual,
    track_path,
)
from .monodromy_stopping import (
    CaptureRecaptureEstimate,
    capture_recapture_estimate,
    second_order_trace_test,
)
from .numerical import number_to_mpc


@dataclass(frozen=True)
class MonodromyLoop:
    """A closed additive coefficient loop for a square polynomial system."""

    equations: tuple[Any, ...]
    variables: tuple[sp.Symbol, ...]
    perturbation: tuple[Any, ...]

    def homotopy(self) -> SympyHomotopy:
        t = sp.Dummy("t", real=True)
        phase = sp.exp(2 * sp.pi * sp.I * t)
        expressions = tuple(
            sp.sympify(eq) + sp.sympify(g) * (1 - phase)
            for eq, g in zip(self.equations, self.perturbation, strict=True)
        )
        return SympyHomotopy(expressions, self.variables, t)


@dataclass(frozen=True)
class MonodromyPermutation:
    """Endpoints and induced matching for one closed loop."""

    endpoints: tuple[tuple[Any, ...], ...]
    permutation: tuple[int | None, ...]
    paths: tuple[PathResult, ...]


@dataclass(frozen=True)
class MonodromyRootInfo:
    """Verification metadata for one root in a monodromy orbit."""

    digits: int
    verification_digits: int
    relative_residual: mp.mpf
    verified: bool
    source_loop: int | None = None
    path_index: int | None = None


@dataclass(frozen=True)
class MonodromyOrbitResult:
    """Roots discovered by repeated closed monodromy loops."""

    roots: tuple[tuple[Any, ...], ...]
    variables: tuple[sp.Symbol, ...]
    equations: tuple[Any, ...]
    loops_completed: int
    paths_tracked: int
    new_roots_per_loop: tuple[int, ...]
    perturbations: tuple[tuple[Any, ...], ...]
    all_paths_successful: bool
    stopping_reason: str = "max_loops"
    completeness_basis: str = "none"
    trace_residual: float | None = None
    population_estimate: CaptureRecaptureEstimate | None = None
    root_info: tuple[MonodromyRootInfo, ...] = ()
    recognized_roots: tuple[RecognizedSystemRoot, ...] | None = None
    recognition_attempted: bool = False
    recognition_error: str | None = None
    tracking_variables: tuple[sp.Symbol, ...] = ()
    tracking_equations: tuple[Any, ...] = ()
    auxiliary_variables: tuple[Any, ...] = ()
    nonzero_constraints: tuple[Any, ...] = ()

    def __post_init__(self) -> None:
        if self.root_info and len(self.root_info) != len(self.roots):
            raise ValueError("root_info must align one-to-one with roots")
        if self.recognized_roots is not None and len(self.recognized_roots) != len(self.roots):
            raise ValueError("recognized_roots must align one-to-one with roots")


def _precision_digits(value: Any) -> int:
    """Estimate stored decimal precision without converting through binary64."""
    if isinstance(value, mp.mpf):
        return max(15, int(value._mpf_[3] * math.log10(2)) + 3)
    if isinstance(value, mp.mpc):
        return max(_precision_digits(value.real), _precision_digits(value.imag))
    expression = sp.sympify(value)
    float_atoms = expression.atoms(sp.Float)
    if float_atoms:
        return max(15, max(int(atom._prec * math.log10(2)) + 3 for atom in float_atoms))
    return max(30, mp.mp.dps)


def _normalized_root_distance(left: Sequence[Any], right: Sequence[Any], digits: int) -> mp.mpf:
    """Return normalized root distance at a caller-supplied precision."""
    if len(left) != len(right):
        raise ValueError("root dimensions must agree")
    with mp.workdps(digits + 10):
        distances: list[mp.mpf] = []
        for a, b in zip(left, right, strict=True):
            aa = number_to_mpc(a, digits + 5)
            bb = number_to_mpc(b, digits + 5)
            distances.append(abs(aa - bb) / max(mp.mpf(1), abs(aa), abs(bb)))
        return max(distances, default=mp.mpf(0))


def normalized_root_distance(left: Sequence[Any], right: Sequence[Any]) -> mp.mpf:
    """Return a scale-normalized root distance at the inputs' stored precision."""
    digits = max(
        [30, mp.mp.dps]
        + [_precision_digits(value) for value in left]
        + [_precision_digits(value) for value in right]
    )
    return _normalized_root_distance(left, right, digits)


def _validate_tolerance(tolerance: float, *, name: str = "tolerance") -> mp.mpf:
    try:
        numeric = mp.mpf(str(tolerance))
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be a finite positive number") from exc
    if not mp.isfinite(numeric) or numeric <= 0:
        raise ValueError(f"{name} must be a finite positive number")
    return numeric


def matching_root_indices(
    root: Sequence[Any],
    roots: Sequence[Sequence[Any]],
    *,
    tolerance: float = 1e-8,
) -> tuple[int, ...]:
    """Return all roots within the requested normalized tolerance."""
    threshold = _validate_tolerance(tolerance)
    return tuple(
        index
        for index, candidate in enumerate(roots)
        if normalized_root_distance(root, candidate) <= threshold
    )


def match_root(
    root: Sequence[Any],
    roots: Sequence[Sequence[Any]],
    *,
    tolerance: float = 1e-8,
) -> int | None:
    """Return a unique tolerance match, or ``None`` when absent/ambiguous."""
    matches = matching_root_indices(root, roots, tolerance=tolerance)
    return matches[0] if len(matches) == 1 else None


def _has_near_root(
    root: Sequence[Any],
    roots: Sequence[Sequence[Any]],
    threshold: mp.mpf,
    *,
    digits: int | None = None,
) -> bool:
    """Return on the first existing root within an already-validated threshold."""
    distance = (
        (lambda candidate: _normalized_root_distance(root, candidate, digits))
        if digits is not None
        else (lambda candidate: normalized_root_distance(root, candidate))
    )
    return any(distance(candidate) <= threshold for candidate in roots)


def _deduplicate_with_threshold(
    roots: Iterable[Sequence[Any]],
    threshold: mp.mpf,
    *,
    digits: int | None = None,
) -> tuple[tuple[Any, ...], ...]:
    """Deduplicate roots using an already-validated tolerance."""
    unique: list[tuple[Any, ...]] = []
    for root in roots:
        value = tuple(root)
        if not _has_near_root(value, unique, threshold, digits=digits):
            unique.append(value)
    return tuple(unique)


def deduplicate_roots(
    roots: Iterable[Sequence[Any]], *, tolerance: float = 1e-8
) -> tuple[tuple[Any, ...], ...]:
    """Deduplicate roots without treating ambiguous proximity as novelty."""
    return _deduplicate_with_threshold(roots, _validate_tolerance(tolerance))


def _root_info(
    path: PathResult,
    base_homotopy: SympyHomotopy,
    options: PathTrackerOptions,
    *,
    source_loop: int | None,
    path_index: int | None,
) -> MonodromyRootInfo:
    """Build high-precision endpoint verification metadata for one root."""
    digits = path.final_digits
    with mp.workdps(digits + 10):
        endpoint = mp.matrix([number_to_mpc(value, digits + 5) for value in path.endpoint])
        residual = _relative_residual(base_homotopy, endpoint, mp.mpf(0))
        verify_digits = min(options.residual_digits, digits - 8)
        target = mp.power(10, -verify_digits)
        stored_residual = mp.mpf(residual)
    return MonodromyRootInfo(
        digits=digits,
        verification_digits=verify_digits,
        relative_residual=stored_residual,
        verified=bool(path.success and stored_residual <= target),
        source_loop=source_loop,
        path_index=path_index,
    )


def _append_root(
    roots: list[tuple[Any, ...]],
    info: list[MonodromyRootInfo],
    root: Sequence[Any],
    root_info: MonodromyRootInfo,
    *,
    threshold: mp.mpf,
) -> bool:
    """Append a root and aligned metadata only when it is new."""
    value = tuple(root)
    if any(
        _normalized_root_distance(value, candidate, max(root_info.digits, prior_info.digits))
        <= threshold
        for candidate, prior_info in zip(roots, info, strict=True)
    ):
        return False
    roots.append(value)
    info.append(root_info)
    return True


def closed_additive_loop(
    equations: Sequence[Any],
    variables: Sequence[sp.Symbol],
    perturbation: Sequence[Any],
) -> MonodromyLoop:
    equations = tuple(sp.sympify(eq) for eq in equations)
    variables = tuple(variables)
    perturbation = tuple(sp.sympify(g) for g in perturbation)
    if not variables:
        raise ValueError("closed additive loops require at least one variable")
    if len(equations) != len(variables) or len(perturbation) != len(equations):
        raise ValueError("closed additive loops require a square system and matching perturbation")
    if len(set(variables)) != len(variables) or not all(
        isinstance(variable, sp.Symbol) for variable in variables
    ):
        raise ValueError("variables must be distinct SymPy symbols")
    for equation in equations:
        try:
            sp.Poly(equation, *variables, extension=True)
        except sp.PolynomialError as exc:
            raise ValueError("monodromy loops currently require polynomial equations") from exc
    return MonodromyLoop(equations, variables, perturbation)


def _track_worker(payload):
    equations, variables, perturbation, start, options = payload
    loop = closed_additive_loop(equations, variables, perturbation)
    return track_path(loop.homotopy(), start, options=options)


def track_loop(
    loop: MonodromyLoop,
    starts: Sequence[Sequence[Any]],
    *,
    options: PathTrackerOptions | None = None,
    parallel: bool = False,
    max_workers: int | None = None,
) -> tuple[PathResult, ...]:
    opts = options or PathTrackerOptions()
    if not parallel or len(starts) <= 1:
        homotopy = loop.homotopy()
        return tuple(track_path(homotopy, start, options=opts) for start in starts)
    payloads = [
        (loop.equations, loop.variables, loop.perturbation, tuple(start), opts) for start in starts
    ]
    with ProcessPoolExecutor(
        max_workers=max_workers,
        mp_context=multiprocessing.get_context("spawn"),
    ) as executor:
        return tuple(executor.map(_track_worker, payloads))


def monodromy_permutation(
    loop: MonodromyLoop,
    roots: Sequence[Sequence[Any]],
    *,
    options: PathTrackerOptions | None = None,
    match_tolerance: float = 1e-7,
    parallel: bool = False,
    max_workers: int | None = None,
) -> MonodromyPermutation:
    _validate_tolerance(match_tolerance, name="match_tolerance")
    if any(len(root) != len(loop.variables) for root in roots):
        raise ValueError("every root must have one coordinate per variable")
    paths = track_loop(
        loop,
        roots,
        options=options,
        parallel=parallel,
        max_workers=max_workers,
    )
    endpoints = tuple(path.endpoint for path in paths)
    permutation = tuple(
        match_root(endpoint, roots, tolerance=match_tolerance) if path.success else None
        for endpoint, path in zip(endpoints, paths, strict=True)
    )
    return MonodromyPermutation(endpoints, permutation, paths)


def random_perturbation(
    count: int,
    *,
    radius: float = 1.0,
    rng: random.Random | None = None,
) -> tuple[complex, ...]:
    if count <= 0:
        raise ValueError("count must be positive")
    if not math.isfinite(radius) or radius <= 0:
        raise ValueError("radius must be finite and positive")
    generator = rng or random.Random()
    values = [complex(generator.gauss(0, 1), generator.gauss(0, 1)) for _ in range(count)]
    norm = math.sqrt(sum(abs(value) ** 2 for value in values))
    if norm == 0:
        values[0] = 1 + 0j
        norm = 1
    return tuple(radius * value / norm for value in values)


def _validate_orbit_options(
    *,
    max_loops: int,
    radius: float,
    match_tolerance: float,
    expected_root_count: int | None,
    trace_tolerance: float,
    confidence: float,
    min_loops_before_stopping: int,
    options: PathTrackerOptions | None,
) -> tuple[PathTrackerOptions, mp.mpf]:
    """Validate orbit controls before algebraization or seed lifting."""
    if not isinstance(max_loops, int) or max_loops <= 0:
        raise ValueError("max_loops must be a positive integer")
    if expected_root_count is not None and (
        not isinstance(expected_root_count, int) or expected_root_count <= 0
    ):
        raise ValueError("expected_root_count must be a positive integer")
    if not math.isfinite(radius) or radius <= 0:
        raise ValueError("radius must be finite and positive")
    threshold = _validate_tolerance(match_tolerance, name="match_tolerance")
    if not math.isfinite(trace_tolerance) or trace_tolerance <= 0:
        raise ValueError("trace_tolerance must be finite and positive")
    if not math.isfinite(confidence) or not 0 < confidence < 1:
        raise ValueError("confidence must lie in (0, 1)")
    if not isinstance(min_loops_before_stopping, int) or min_loops_before_stopping <= 0:
        raise ValueError("min_loops_before_stopping must be a positive integer")
    return options or PathTrackerOptions(), threshold


def _validate_tracking_system(
    equations: Sequence[Any],
    variables: Sequence[sp.Symbol],
    seeds: Sequence[Sequence[Any]],
) -> tuple[tuple[Any, ...], tuple[sp.Symbol, ...], tuple[tuple[Any, ...], ...]]:
    """Validate the polynomial tracking system and lifted seed dimensions."""
    vars_tuple = tuple(variables)
    eq_tuple = tuple(sp.sympify(eq) for eq in equations)
    seed_tuple = tuple(tuple(seed) for seed in seeds)
    closed_additive_loop(eq_tuple, vars_tuple, [sp.Integer(0)] * len(eq_tuple))
    if not seed_tuple:
        raise ValueError("at least one seed root is required")
    if any(len(seed) != len(vars_tuple) for seed in seed_tuple):
        raise ValueError("every seed root must have one coordinate per variable")
    return eq_tuple, vars_tuple, seed_tuple


def _prepare_seed_roots(
    equations: tuple[Any, ...],
    variables: tuple[sp.Symbol, ...],
    seeds: tuple[tuple[Any, ...], ...],
    options: PathTrackerOptions,
    threshold: mp.mpf,
) -> tuple[SympyHomotopy, list[tuple[Any, ...]], list[MonodromyRootInfo]]:
    """Correct, verify, and deduplicate seeds on the closed base system."""
    parameter = sp.Dummy("t", real=True)
    base = SympyHomotopy(equations, variables, parameter)
    roots: list[tuple[Any, ...]] = []
    info: list[MonodromyRootInfo] = []
    for seed_index, seed in enumerate(seeds):
        result = track_path(base, seed, t_start=0.0, t_end=0.0, options=options)
        if not result.success:
            raise ValueError("every seed must correct to a verified root of the base system")
        _append_root(
            roots,
            info,
            result.endpoint,
            _root_info(
                result,
                base,
                options,
                source_loop=None,
                path_index=seed_index,
            ),
            threshold=threshold,
        )
    return base, roots, info


def _sync_projected_roots(
    tracking_roots: Sequence[tuple[Any, ...]],
    tracking_info: Sequence[MonodromyRootInfo],
    projector: _AlgebraicProjector,
    roots: list[tuple[Any, ...]],
    root_info: list[MonodromyRootInfo],
    *,
    start_index: int,
    threshold: mp.mpf,
    require_valid: bool = False,
) -> int:
    """Project newly tracked roots and retain only original-system solutions."""
    added = 0
    new_roots = tracking_roots[start_index:]
    new_info = tracking_info[start_index:]
    precisions = tuple((item.digits, item.verification_digits) for item in new_info)
    candidates = _project_candidates(projector, new_roots, precisions)
    for candidate, info in zip(candidates, new_info, strict=True):
        if candidate is None:
            if require_valid:
                raise ValueError(
                    "every seed must satisfy the original algebraic equations and branch constraints"
                )
            continue
        public_info = replace(
            info,
            relative_residual=candidate.relative_residual,
            verified=True,
        )
        added += int(
            _append_root(
                roots,
                root_info,
                candidate.root,
                public_info,
                threshold=threshold,
            )
        )
    return added


def _population_from_paths(
    starts: tuple[tuple[Any, ...], ...],
    paths: tuple[PathResult, ...],
    threshold: mp.mpf,
    confidence: float,
) -> CaptureRecaptureEstimate | None:
    endpoints = [tuple(path.endpoint) for path in paths if path.success]
    distance_digits = max((path.final_digits for path in paths if path.success), default=30)
    unique = _deduplicate_with_threshold(endpoints, threshold, digits=distance_digits)
    if not unique:
        return None
    recaptured = sum(_has_near_root(endpoint, starts, threshold) for endpoint in unique)
    return capture_recapture_estimate(
        len(starts),
        len(unique),
        recaptured,
        confidence=confidence,
    )


def _admit_endpoints(
    paths: tuple[PathResult, ...],
    base: SympyHomotopy,
    options: PathTrackerOptions,
    roots: list[tuple[Any, ...]],
    info: list[MonodromyRootInfo],
    *,
    loop_index: int,
    threshold: mp.mpf,
) -> tuple[int, bool]:
    """Re-verify successful loop endpoints and admit only new base roots."""
    new_count = 0
    all_successful = True
    option_cache: dict[int, PathTrackerOptions] = {}
    for path_index, path in enumerate(paths):
        all_successful = all_successful and path.success
        if not path.success:
            continue
        initial_digits = max(options.initial_digits, path.final_digits)
        verify_options = option_cache.get(initial_digits)
        if verify_options is None:
            verify_options = replace(options, initial_digits=initial_digits)
            option_cache[initial_digits] = verify_options
        verified = track_path(
            base,
            path.endpoint,
            t_start=0.0,
            t_end=0.0,
            options=verify_options,
        )
        all_successful = all_successful and verified.success
        if not verified.success:
            continue
        added = _append_root(
            roots,
            info,
            verified.endpoint,
            _root_info(
                verified,
                base,
                verify_options,
                source_loop=loop_index,
                path_index=path_index,
            ),
            threshold=threshold,
        )
        new_count += int(added)
    return new_count, all_successful


def _stop_decision(
    *,
    roots: list[tuple[Any, ...]],
    trace_equations: tuple[Any, ...],
    trace_variables: tuple[sp.Symbol, ...],
    trace_roots: list[tuple[Any, ...]],
    loops_completed: int,
    new_count: int,
    expected_root_count: int | None,
    trace_test: bool,
    trace_tolerance: float,
    statistical_stop: bool,
    population_estimate: CaptureRecaptureEstimate | None,
    min_loops_before_stopping: int,
    trace_digits: int,
) -> tuple[str, str, float | None] | None:
    """Return a stopping reason, completeness basis, and optional trace residual."""
    if expected_root_count is not None:
        if len(roots) > expected_root_count:
            raise ValueError("monodromy discovered more distinct roots than expected_root_count")
        if len(roots) == expected_root_count:
            return "expected_root_count", "exact_root_count", None

    enough_loops = loops_completed >= min_loops_before_stopping
    if enough_loops and new_count == 0 and trace_test:
        residual = second_order_trace_test(
            trace_equations,
            trace_variables,
            trace_roots,
            digits=trace_digits,
        )
        if residual <= trace_tolerance:
            return "trace_test", "none", residual

    if (
        enough_loops
        and new_count == 0
        and statistical_stop
        and population_estimate is not None
        and population_estimate.upper <= len(roots) + 0.5
    ):
        return "statistical", "statistical", None
    return None


def _orbit_result(
    roots: list[tuple[Any, ...]],
    variables: tuple[sp.Symbol, ...],
    equations: tuple[Any, ...],
    *,
    algebraized: AlgebraizedSystem,
    loops_completed: int,
    paths_tracked: int,
    discovered: list[int],
    perturbations: list[tuple[Any, ...]],
    all_successful: bool,
    stopping_reason: str,
    completeness_basis: str,
    trace_residual: float | None,
    population_estimate: CaptureRecaptureEstimate | None,
    root_info: list[MonodromyRootInfo],
) -> MonodromyOrbitResult:
    return MonodromyOrbitResult(
        roots=tuple(roots),
        variables=variables,
        equations=equations,
        loops_completed=loops_completed,
        paths_tracked=paths_tracked,
        new_roots_per_loop=tuple(discovered),
        perturbations=tuple(perturbations),
        all_paths_successful=all_successful,
        stopping_reason=stopping_reason,
        completeness_basis=completeness_basis,
        trace_residual=trace_residual,
        population_estimate=population_estimate,
        root_info=tuple(root_info),
        tracking_variables=algebraized.augmented_variables,
        tracking_equations=algebraized.polynomial_equations,
        auxiliary_variables=algebraized.auxiliary_variables,
        nonzero_constraints=algebraized.nonzero_constraints,
    )


def discover_monodromy_orbit(
    equations: Sequence[Any],
    variables: Sequence[sp.Symbol],
    seeds: Sequence[Sequence[Any]],
    *,
    max_loops: int = 10,
    radius: float = 1.0,
    match_tolerance: float = 1e-7,
    random_seed: int | None = None,
    options: PathTrackerOptions | None = None,
    parallel: bool = False,
    max_workers: int | None = None,
    expected_root_count: int | None = None,
    trace_test: bool = False,
    trace_tolerance: float = 1e-8,
    statistical_stop: bool = False,
    confidence: float = 0.95,
    min_loops_before_stopping: int = 2,
    max_auxiliary_variables: int = 32,
    recognize: bool = True,
    recognition_max_degree: int = 8,
) -> MonodromyOrbitResult:
    """Discover roots by monodromy for polynomial or supported algebraic systems.

    Algebraic inputs use the same algebraization and principal-branch semantics as
    :func:`algsolve`. Tracking occurs in the augmented polynomial space,
    while returned roots are projected to the original variables and reverified
    against the original equations and denominator constraints.

    Exact algebraic recognition is attempted by default for the retained roots.
    Set ``recognize=False`` to skip that post-processing step.
    """

    def finish(result: MonodromyOrbitResult) -> MonodromyOrbitResult:
        from .recognition import _auto_recognize

        return _auto_recognize(result, recognize=recognize, max_degree=recognition_max_degree)

    validate_recognition_options(recognize, recognition_max_degree)

    tracker_options, threshold = _validate_orbit_options(
        max_loops=max_loops,
        radius=radius,
        match_tolerance=match_tolerance,
        expected_root_count=expected_root_count,
        trace_tolerance=trace_tolerance,
        confidence=confidence,
        min_loops_before_stopping=min_loops_before_stopping,
        options=options,
    )
    algebraized = algebraize_system(
        equations,
        variables,
        max_auxiliary_variables=max_auxiliary_variables,
    )
    projector = _AlgebraicProjector(algebraized)
    lifted_seeds = tuple(
        projector.lift(seed, tracker_options.initial_digits + 10) for seed in seeds
    )
    tracking_equations, tracking_variables, lifted_seeds = _validate_tracking_system(
        algebraized.polynomial_equations,
        algebraized.augmented_variables,
        lifted_seeds,
    )
    base, tracking_roots, tracking_info = _prepare_seed_roots(
        tracking_equations,
        tracking_variables,
        lifted_seeds,
        tracker_options,
        threshold,
    )
    roots: list[tuple[Any, ...]] = []
    root_info: list[MonodromyRootInfo] = []
    _sync_projected_roots(
        tracking_roots,
        tracking_info,
        projector,
        roots,
        root_info,
        start_index=0,
        threshold=threshold,
        require_valid=True,
    )
    if expected_root_count is not None and len(roots) > expected_root_count:
        raise ValueError("expected_root_count is smaller than the number of distinct seed roots")

    initial_stop = _stop_decision(
        roots=roots,
        trace_equations=tracking_equations,
        trace_variables=tracking_variables,
        trace_roots=tracking_roots,
        loops_completed=0,
        new_count=0,
        expected_root_count=expected_root_count,
        trace_test=False,
        trace_tolerance=trace_tolerance,
        statistical_stop=False,
        population_estimate=None,
        min_loops_before_stopping=min_loops_before_stopping,
        trace_digits=tracker_options.initial_digits,
    )
    if initial_stop is not None:
        reason, basis, trace_residual = initial_stop
        result = _orbit_result(
            roots,
            algebraized.original_variables,
            algebraized.original_equations,
            algebraized=algebraized,
            loops_completed=0,
            paths_tracked=0,
            discovered=[],
            perturbations=[],
            all_successful=True,
            stopping_reason=reason,
            completeness_basis=basis,
            trace_residual=trace_residual,
            population_estimate=None,
            root_info=root_info,
        )
        return finish(result)

    rng = random.Random(random_seed)
    perturbations: list[tuple[Any, ...]] = []
    discovered: list[int] = []
    paths_tracked = 0
    all_successful = True
    stopping_reason = "max_loops"
    completeness_basis = "none"
    trace_residual: float | None = None
    population_estimate: CaptureRecaptureEstimate | None = None
    loops_completed = 0

    for loop_index in range(1, max_loops + 1):
        perturbation = random_perturbation(len(tracking_equations), radius=radius, rng=rng)
        perturbations.append(perturbation)
        loop = closed_additive_loop(tracking_equations, tracking_variables, perturbation)
        starts = tuple(tracking_roots)
        paths = track_loop(
            loop,
            starts,
            options=tracker_options,
            parallel=parallel,
            max_workers=max_workers,
        )
        loops_completed = loop_index
        paths_tracked += len(paths)
        population_estimate = _population_from_paths(
            starts,
            paths,
            threshold,
            confidence,
        )
        tracking_start = len(tracking_roots)
        _, loop_success = _admit_endpoints(
            paths,
            base,
            tracker_options,
            tracking_roots,
            tracking_info,
            loop_index=loop_index,
            threshold=threshold,
        )
        all_successful = all_successful and loop_success
        new_count = _sync_projected_roots(
            tracking_roots,
            tracking_info,
            projector,
            roots,
            root_info,
            start_index=tracking_start,
            threshold=threshold,
        )
        discovered.append(new_count)

        stop = _stop_decision(
            roots=roots,
            trace_equations=tracking_equations,
            trace_variables=tracking_variables,
            trace_roots=tracking_roots,
            loops_completed=loops_completed,
            new_count=new_count,
            expected_root_count=expected_root_count,
            trace_test=trace_test,
            trace_tolerance=trace_tolerance,
            statistical_stop=statistical_stop,
            population_estimate=population_estimate,
            min_loops_before_stopping=min_loops_before_stopping,
            trace_digits=tracker_options.initial_digits,
        )
        if stop is not None:
            stopping_reason, completeness_basis, trace_residual = stop
            break

    result = _orbit_result(
        roots,
        algebraized.original_variables,
        algebraized.original_equations,
        algebraized=algebraized,
        loops_completed=loops_completed,
        paths_tracked=paths_tracked,
        discovered=discovered,
        perturbations=perturbations,
        all_successful=all_successful,
        stopping_reason=stopping_reason,
        completeness_basis=completeness_basis,
        trace_residual=trace_residual,
        population_estimate=population_estimate,
        root_info=root_info,
    )
    return finish(result)
