"""Numerical roots of exact zero-dimensional polynomial systems."""

from __future__ import annotations

from collections.abc import Iterable, Sequence
from dataclasses import dataclass, replace
from time import perf_counter
from typing import TYPE_CHECKING, Any, Literal

import mpmath as mp
import sympy as sp

from ._validation import (
    normalize_equation,
    validate_integer,
    validate_recognition_options,
    validate_variables,
)
from .continuation import PathResult, PathTrackerOptions
from .errors import (
    ActionMatrixError,
    HomotopySolveError,
    NotZeroDimensionalError,
    NumericalRootError,
    PolynomialSystemError,
    PolynomialSystemInputError,
    QuotientAlgebraError,
    ShapePositionError,
    SystemSolveLimitError,
    TriangularSolveError,
)
from .numerical import (
    acb_mid_to_sympy,
    compile_polynomials,
    compiled_jacobian,
    compiled_residual,
    flint_available,
    flint_dps,
    newton_refine,
    sympy_to_acb,
    sympy_to_mpc,
)
from .numerical import (
    mpc_to_sympy as _sympy_numeric,
)
from .quotient import QuotientAlgebra
from .root_output import (
    RootOrderingEvidence,
    RootViews,
    finish_root_output,
    validate_output_options,
)
from .total_degree_homotopy import (
    TotalDegreeHomotopy,
    TotalDegreeHomotopyOptions,
    build_total_degree_homotopy,
    gamma_candidates,
    track_total_degree_paths,
)

if TYPE_CHECKING:
    from .recognition import RecognizedSystemRoot


SolveMethod = Literal["auto", "shape", "action", "triangular", "rur", "homotopy"]


@dataclass(frozen=True)
class CompletenessEvidence:
    """Enumeration evidence, separate from coordinate or residual certification."""

    status: str = "unknown"
    basis: str = "none"
    expected_count: int | None = None
    distinct_roots: int = 0
    quotient_dimension: int | None = None
    notes: tuple[str, ...] = ()


@dataclass(frozen=True)
class SolveCostDiagnostics:
    """Observed timings and structural cost hints; never mathematical evidence."""

    phase_seconds: tuple = ()
    structural_estimates: tuple = ()
    normal_form_statistics: tuple = ()
    policy: str = "calibrated-v2"
    quotient_operation_statistics: tuple = ()


@dataclass(frozen=True)
class RootDiagnostics:
    """Numerical validation data for one returned solution tuple."""

    initial_relative_residual: Any
    final_relative_residual: Any
    refinement_attempted: bool
    refinement_succeeded: bool
    refinement_improved: bool


@dataclass(frozen=True)
class _EndpointRegularity:
    smallest_singular_value: mp.mpf
    condition_estimate: mp.mpf
    digits: int
    resolved: bool


@dataclass(frozen=True)
class _CompiledPolynomialSystem:
    expressions: tuple[Any, ...]
    variables: tuple[Any, ...]
    polynomials: tuple[Any, ...]
    jacobian: tuple[tuple[Any, ...], ...]

    @classmethod
    def build(
        cls, expressions: tuple[Any, ...], variables: tuple[Any, ...]
    ) -> _CompiledPolynomialSystem:
        return cls(
            expressions,
            variables,
            compile_polynomials(expressions, variables),
            compiled_jacobian(expressions, variables),
        )

    def residual(self, values: tuple[Any, ...], digits: int) -> mp.mpf:
        return compiled_residual(self.polynomials, values, digits)

    def endpoint_regularity(
        self, root: tuple[Any, ...], *, digits: int, verification_digits: int
    ) -> _EndpointRegularity:
        with mp.workdps(digits + 10):
            values = _mp_root(root, digits + 5)
            variable_scales = [max(mp.mpf(1), abs(value)) for value in values]
            rows: list[list[mp.mpc]] = []
            for row_index, polynomial in enumerate(self.polynomials):
                equation_scale = mp.mpf(0)
                for coefficient, powers in polynomial.terms:
                    term = abs(sympy_to_mpc(coefficient, digits + 5))
                    for scale, power in zip(variable_scales, powers, strict=True):
                        if power:
                            term *= scale**power
                    equation_scale += term
                if equation_scale == 0:
                    return _EndpointRegularity(mp.mpf(0), mp.inf, digits, False)
                row: list[mp.mpc] = []
                for column, derivative in enumerate(self.jacobian[row_index]):
                    derivative_value = derivative.evaluate_mp(values, digits + 5)[0]
                    row.append(derivative_value * variable_scales[column] / equation_scale)
                rows.append(row)
            matrix = mp.matrix(rows)
            try:
                singular_values = [abs(value) for value in mp.svd(matrix, compute_uv=False)]
            except (ValueError, ZeroDivisionError):
                return _EndpointRegularity(mp.mpf(0), mp.inf, digits, False)
            if not singular_values:
                return _EndpointRegularity(mp.mpf(0), mp.inf, digits, False)
            smallest = min(singular_values)
            largest = max(singular_values)
            condition = mp.inf if smallest == 0 else largest / smallest
            resolution_threshold = mp.power(10, -max(8, digits - 8))
            return _EndpointRegularity(
                smallest, condition, digits, bool(smallest > resolution_threshold)
            )


@dataclass(frozen=True)
class PolynomialSystemRoots(RootViews):
    """All distinct verified numerical roots found for a polynomial system.

    Coordinates are SymPy arbitrary-precision numbers in the same order as
    ``variables``. Every returned root has been checked against the original
    equations after a higher-precision refinement attempt. ``diagnostics`` is
    aligned with ``roots`` and records the residual before and after refinement.
    """

    roots: tuple[tuple[Any, ...], ...]
    variables: tuple[Any, ...]
    equations: tuple[Any, ...]
    groebner_basis: tuple[Any, ...]
    precision_digits: int
    working_digits: int
    verification_digits: int
    max_relative_residual: Any
    method: str
    diagnostics: tuple[RootDiagnostics, ...] = ()
    eliminant: Any | None = None
    parameter_variable: Any | None = None
    quotient_dimension: int | None = None
    standard_monomials: tuple[tuple[int, ...], ...] | None = None
    separator_coeffs: tuple[int, ...] | None = None
    recognized_roots: tuple[RecognizedSystemRoot, ...] | None = None
    rational_univariate_representation: Any | None = None
    homotopy_paths_total: int | None = None
    homotopy_paths_succeeded: int | None = None
    homotopy_paths_failed: int | None = None
    homotopy_paths_divergent: int | None = None
    homotopy_gamma: Any | None = None
    homotopy_gamma_attempts: int | None = None
    homotopy_endpoint_smallest_singular_values: tuple[Any, ...] | None = None
    homotopy_endpoint_condition_estimates: tuple[Any, ...] | None = None
    completeness: CompletenessEvidence = CompletenessEvidence()
    geometric_solution_count: int | None = None
    total_multiplicity: int | None = None
    is_radical: bool | None = None
    has_multiple_roots: bool | None = None
    solver_variables: tuple[Any, ...] | None = None
    affine_substitutions: tuple[tuple[Any, Any], ...] = ()

    multiplicities: tuple[int | None, ...] | None = None
    multiplicity_evidence: tuple[str, ...] = ()
    multiplicity_certifications: tuple[Any, ...] | None = None
    ordering: RootOrderingEvidence = RootOrderingEvidence()
    root_mode: str = "distinct"
    max_returned_roots: int = 10_000

    recognition_attempted: bool = False
    recognition_error: str | None = None
    root_certifications: tuple[Any, ...] | None = None
    root_deflations: tuple[Any, ...] | None = None
    recovery_records: tuple[Any, ...] = ()
    cost_diagnostics: SolveCostDiagnostics | None = None

    def __post_init__(self) -> None:
        for name in ("multiplicities", "multiplicity_certifications"):
            values = getattr(self, name)
            if values is not None and len(values) != len(self.roots):
                raise ValueError(f"{name} must align one-to-one with roots")
        if self.multiplicities is not None and any(
            value is not None
            and (isinstance(value, bool) or not isinstance(value, int) or value < 1)
            for value in self.multiplicities
        ):
            raise ValueError("multiplicities must be positive integers or unknown")
        if self.multiplicity_evidence and len(self.multiplicity_evidence) != len(self.roots):
            raise ValueError("multiplicity_evidence must align one-to-one with roots")
        if self.root_certifications is not None and len(self.root_certifications) != len(
            self.roots
        ):
            raise ValueError("root_certifications must align one-to-one with roots")
        if self.recognized_roots is not None and len(self.recognized_roots) != len(self.roots):
            raise ValueError("recognized_roots must align one-to-one with roots")


@dataclass(frozen=True)
class _ShapeRepresentation:
    parameter: Any
    eliminant: Any
    coordinate_exprs: tuple[Any, ...]


def _normalize_equations(
    equations: Iterable[Any],
    variables: tuple[Any, ...],
) -> tuple[Any, ...]:
    normalized: list[Any] = []
    for equation in equations:
        expression = normalize_equation(equation, expand=True)
        try:
            polynomial = sp.Poly(expression, *variables, extension=True)
        except (sp.PolynomialError, TypeError, ValueError) as exc:
            raise PolynomialSystemInputError(
                f"equation is not polynomial in the supplied variables: {equation!r}"
            ) from exc

        for coefficient in polynomial.coeffs():
            if coefficient.is_algebraic is not True:
                raise PolynomialSystemInputError(
                    "polynomial coefficients must be exact algebraic numbers; "
                    f"unsupported coefficient: {coefficient!r}"
                )
        normalized.append(polynomial.as_expr())

    if not normalized:
        raise PolynomialSystemInputError("at least one equation is required")
    return tuple(normalized)


def _groebner_basis(equations: tuple[Any, ...], variables: tuple[Any, ...]):
    try:
        return sp.groebner(
            equations,
            *variables,
            order="grevlex",
            extension=True,
        )
    except (sp.PolynomialError, TypeError, ValueError) as exc:
        raise PolynomialSystemInputError(
            "could not construct an exact Gröbner basis for the system"
        ) from exc


def _is_unit_ideal(basis) -> bool:
    return len(basis.polys) == 1 and basis.polys[0].as_expr() == 1


def _relative_residual(
    expression: Any,
    variables: tuple[Any, ...],
    assignment: dict[Any, Any],
    digits: int,
):
    polynomial = sp.Poly(expression, *variables, extension=True)
    value = abs(sp.N(expression.subs(assignment), digits))

    term_scale = sp.Float(0, digits)
    for powers, coefficient in polynomial.terms():
        term = sp.N(coefficient, digits)
        for variable, power in zip(variables, powers, strict=True):
            if power:
                term *= assignment[variable] ** power
        term_scale += abs(term)

    scale = max(sp.Float(1, digits), sp.N(term_scale, digits))
    return sp.N(value / scale, digits)


def _assignment_satisfies(
    expressions: Iterable[Any],
    variables: tuple[Any, ...],
    assignment: dict[Any, Any],
    tolerance: Any,
    digits: int,
) -> bool:
    assigned = set(assignment)
    for expression in expressions:
        if expression.free_symbols <= assigned:
            residual = _relative_residual(
                expression,
                variables,
                assignment,
                digits,
            )
            if residual > tolerance:
                return False
    return True


def _nroots(*args, **kwargs):
    # Compatibility hook used by existing shape/triangular callers.
    from .univariate import numerical_univariate_roots

    return numerical_univariate_roots(*args, **kwargs)


def _shape_representation(
    basis_exprs: tuple[Any, ...],
    variables: tuple[Any, ...],
) -> _ShapeRepresentation | None:
    parameter = variables[-1]

    eliminants: list[Any] = []
    for expression in basis_exprs:
        if expression.free_symbols <= {parameter} and parameter in expression.free_symbols:
            try:
                degree = sp.Poly(expression, parameter, extension=True).degree()
            except (sp.PolynomialError, TypeError, ValueError):
                continue
            if degree > 0:
                eliminants.append(expression)

    if not eliminants:
        return None
    eliminants.sort(
        key=lambda expr: (
            sp.Poly(expr, parameter, extension=True).degree(),
            int(sp.count_ops(expr)),
        )
    )
    eliminant = eliminants[0]

    coordinate_exprs: list[Any] = []
    for variable in variables[:-1]:
        relation = None
        for expression in basis_exprs:
            if variable not in expression.free_symbols:
                continue
            if not expression.free_symbols <= {variable, parameter}:
                continue
            try:
                polynomial = sp.Poly(expression, variable, domain="EX")
            except (sp.PolynomialError, TypeError, ValueError):
                continue
            if polynomial.degree() != 1:
                continue

            coeff = sp.expand(polynomial.coeff_monomial(variable))
            constant = sp.expand(polynomial.coeff_monomial(1))
            if coeff.free_symbols:
                continue
            if coeff == 0 or coeff.is_algebraic is not True:
                continue

            candidate = sp.cancel(-constant / coeff)
            if candidate.free_symbols <= {parameter}:
                relation = candidate
                break

        if relation is None:
            return None
        coordinate_exprs.append(relation)

    coordinate_exprs.append(parameter)
    return _ShapeRepresentation(
        parameter=parameter,
        eliminant=eliminant,
        coordinate_exprs=tuple(coordinate_exprs),
    )


def _solve_shape(
    representation: _ShapeRepresentation,
    normalized: tuple[Any, ...],
    basis_exprs: tuple[Any, ...],
    variables: tuple[Any, ...],
    *,
    digits: int,
    work_digits: int,
    verification_digits: int,
    maxsteps: int,
    max_solutions: int,
    max_precision_digits: int | None,
) -> PolynomialSystemRoots:
    parameter_roots = _nroots(
        representation.eliminant,
        representation.parameter,
        work_digits,
        maxsteps,
        max_precision_digits,
    )
    if len(parameter_roots) > max_solutions:
        raise SystemSolveLimitError(f"solution count exceeds max_solutions={max_solutions}")

    parameter = representation.parameter
    coordinate_polys = tuple(
        sp.Poly(expression, parameter, extension=True)
        for expression in representation.coordinate_exprs
    )

    def evaluate_coordinate(poly, root):
        with mp.workdps(work_digits + 8):
            value = mp.mpc(0)
            root_mp = sympy_to_mpc(root, work_digits + 8)
            for coefficient in poly.all_coeffs():
                value = value * root_mp + sympy_to_mpc(coefficient, work_digits + 8)
            return _sympy_numeric(value, work_digits)

    candidates = [
        tuple(evaluate_coordinate(poly, root) for poly in coordinate_polys)
        for root in parameter_roots
    ]
    roots, diagnostics, max_residual = _validate_roots(
        candidates,
        normalized,
        variables,
        digits=digits,
        work_digits=work_digits,
        verification_digits=verification_digits,
        maxsteps=maxsteps,
        expected_count=len(parameter_roots),
        error_type=NumericalRootError,
    )
    return PolynomialSystemRoots(
        roots=roots,
        variables=variables,
        equations=normalized,
        groebner_basis=basis_exprs,
        precision_digits=digits,
        working_digits=work_digits,
        verification_digits=verification_digits,
        max_relative_residual=max_residual,
        method="shape_position",
        diagnostics=diagnostics,
        eliminant=representation.eliminant,
        parameter_variable=representation.parameter,
    )


def _separator_candidates(count: int) -> tuple[tuple[int, ...], ...]:
    candidates = [tuple(index + 1 for index in range(count))]
    candidates.extend(tuple((index + 1) ** power for index in range(count)) for power in (2, 3, 4))
    candidates.extend(
        tuple(1 if index == pivot else 2 * index + 3 for index in range(count))
        for pivot in range(count)
    )
    unique: list[tuple[int, ...]] = []
    for candidate in candidates:
        if candidate not in unique:
            unique.append(candidate)
    return tuple(unique)


def _acb_separator_matrix(
    columns: tuple[tuple[Any, ...], ...],
    digits: int,
):
    """Construct M_L^T directly as an acb_mat."""
    from flint import acb_mat

    # ``columns[c][r]`` is row ``r`` of column ``c`` of the multiplication
    # matrix M_L.  Evaluation vectors are left eigenvectors of M_L, or
    # equivalently right eigenvectors of M_L.T.  Build the transpose here so
    # the right eigenvectors returned by python-flint have monomial-evaluation
    # coordinates, matching the exact fallback below.
    rows = [[sympy_to_acb(value, digits) for value in column] for column in columns]
    return acb_mat(rows)


def _coords_from_acb_vectors(
    eigenvectors: Any,
    coordinate_forms: tuple[tuple[Any, ...], ...],
    monomials: tuple[tuple[int, ...], ...],
    digits: int,
) -> list[tuple[Any, ...]]:
    constant_index = monomials.index((0,) * len(monomials[0]))
    dimension = len(monomials)
    roots: list[tuple[Any, ...]] = []
    for column in range(dimension):
        denominator = eigenvectors[constant_index, column]
        coordinates = []
        for form in coordinate_forms:
            value = sum(
                (
                    sympy_to_acb(coeff, digits) * eigenvectors[row, column]
                    for row, coeff in enumerate(form)
                    if coeff != 0
                ),
                sympy_to_acb(0, digits),
            )
            try:
                coordinates.append(acb_mid_to_sympy(value / denominator, digits))
            except (ValueError, ZeroDivisionError) as exc:
                raise ActionMatrixError(
                    "separator eigenvector could not be normalized at the constant basis element"
                ) from exc
        roots.append(tuple(coordinates))
    return roots


def _exact_action_fallback(
    columns: tuple[tuple[Any, ...], ...],
    coordinate_forms: tuple[tuple[Any, ...], ...],
    monomials: tuple[tuple[int, ...], ...],
    digits: int,
) -> list[tuple[Any, ...]]:
    """Small development fallback when python-flint is unavailable."""
    dimension = len(columns)
    matrix = sp.Matrix(dimension, dimension, lambda r, c: columns[c][r]).T
    eigenvectors = []
    for _, multiplicity, vectors in matrix.eigenvects():
        if multiplicity != 1 or len(vectors) != 1:
            raise ActionMatrixError("separator has non-simple eigenvalues")
        eigenvectors.append(vectors[0])
    if len(eigenvectors) != dimension:
        raise ActionMatrixError("separator did not yield a complete simple eigenbasis")
    constant_index = monomials.index((0,) * len(monomials[0]))
    roots = []
    for vector in eigenvectors:
        denominator = vector[constant_index]
        if denominator == 0:
            raise ActionMatrixError("separator eigenvector has zero constant coordinate")
        root = []
        for form in coordinate_forms:
            value = sum(coeff * vector[row] for row, coeff in enumerate(form)) / denominator
            root.append(sp.N(value, digits))
        roots.append(tuple(root))
    return roots


def _mp_root(root: tuple[Any, ...], digits: int) -> tuple[mp.mpc, ...]:
    return tuple(sympy_to_mpc(value, digits) for value in root)


def _sp_root(root: tuple[Any, ...], digits: int) -> tuple[Any, ...]:
    return tuple(_sympy_numeric(value, digits) for value in root)


def _deduplicate_records(
    records: list[tuple[tuple[Any, ...], RootDiagnostics]],
    digits: int,
) -> list[tuple[tuple[Any, ...], RootDiagnostics]]:
    tolerance = sp.Float(10, digits) ** (-digits)
    unique: list[tuple[tuple[Any, ...], RootDiagnostics]] = []
    for root, diagnostics in sorted(records, key=lambda item: _root_sort_key(item[0])):
        duplicate_index = next(
            (
                index
                for index, (prior, _) in enumerate(unique)
                if _roots_close(root, prior, tolerance)
            ),
            None,
        )
        if duplicate_index is None:
            unique.append((root, diagnostics))
            continue
        _, prior_diag = unique[duplicate_index]
        if diagnostics.final_relative_residual < prior_diag.final_relative_residual:
            unique[duplicate_index] = (root, diagnostics)
    return unique


def _validate_roots(
    candidates: Iterable[tuple[Any, ...]],
    normalized: tuple[Any, ...],
    variables: tuple[Any, ...],
    *,
    digits: int,
    work_digits: int,
    verification_digits: int,
    maxsteps: int,
    expected_count: int | None = None,
    error_type: type[PolynomialSystemError] = NumericalRootError,
    compiled_system: _CompiledPolynomialSystem | None = None,
) -> tuple[
    tuple[tuple[Any, ...], ...],
    tuple[RootDiagnostics, ...],
    Any,
]:
    """Refine candidates numerically and verify compiled original polynomials."""
    compiled_system = compiled_system or _CompiledPolynomialSystem.build(normalized, variables)
    polynomials = compiled_system.polynomials
    jacobian = compiled_system.jacobian
    tolerance_mp = mp.power(10, -verification_digits)
    records: list[tuple[tuple[Any, ...], RootDiagnostics]] = []

    for candidate in candidates:
        candidate_mp = _mp_root(tuple(candidate), work_digits + 8)
        initial_mp = compiled_residual(polynomials, candidate_mp, work_digits + 5)
        refine_digits = min(work_digits - 5, verification_digits + 8)
        refine_threshold = mp.power(10, -refine_digits)
        if mp.isfinite(initial_mp) and initial_mp <= refine_threshold:
            refined_mp = candidate_mp
            attempted = False
            succeeded = False
        else:
            attempted = len(normalized) >= len(variables)
            if attempted:
                refined_mp, succeeded = newton_refine(
                    polynomials, jacobian, candidate_mp, work_digits, maxsteps
                )
            else:
                refined_mp, succeeded = candidate_mp, False

        refined_residual = compiled_residual(polynomials, refined_mp, work_digits + 5)
        improved = bool(
            succeeded and mp.isfinite(refined_residual) and refined_residual < initial_mp
        )
        accepted_mp = (
            refined_mp
            if succeeded and mp.isfinite(refined_residual) and refined_residual <= initial_mp
            else candidate_mp
        )
        output_root = _sp_root(accepted_mp, digits)
        output_mp = _mp_root(output_root, work_digits + 5)
        final_mp = compiled_residual(polynomials, output_mp, work_digits + 5)
        if not mp.isfinite(final_mp) or final_mp > tolerance_mp:
            continue

        diagnostics = RootDiagnostics(
            initial_relative_residual=sp.Float(mp.nstr(initial_mp, work_digits), work_digits),
            final_relative_residual=sp.Float(mp.nstr(final_mp, work_digits), work_digits),
            refinement_attempted=attempted,
            refinement_succeeded=succeeded,
            refinement_improved=improved,
        )
        records.append((output_root, diagnostics))

    records = _deduplicate_records(records, digits)
    if expected_count is not None and len(records) != expected_count:
        raise error_type(
            "numerical validation did not retain the expected number of distinct "
            f"roots ({len(records)} != {expected_count})"
        )
    if not records and expected_count != 0:
        raise error_type("candidate roots did not verify against the original polynomial system")

    roots = tuple(root for root, _ in records)
    diagnostics = tuple(diag for _, diag in records)
    max_residual = max(
        (diag.final_relative_residual for diag in diagnostics),
        default=sp.Float(0, work_digits),
    )
    return roots, diagnostics, max_residual


def _solve_action_matrix(
    normalized: tuple[Any, ...],
    basis,
    basis_exprs: tuple[Any, ...],
    variables: tuple[Any, ...],
    *,
    digits: int,
    work_digits: int,
    verification_digits: int,
    maxsteps: int,
    max_solutions: int,
    max_action_dimension: int,
    max_precision_digits: int | None,
    quotient: QuotientAlgebra | None = None,
) -> PolynomialSystemRoots:
    try:
        quotient = (
            quotient
            if quotient is not None
            else QuotientAlgebra.from_groebner_basis(
                basis, variables, max_dimension=max_action_dimension
            )
        )
    except QuotientAlgebraError as exc:
        raise ActionMatrixError(str(exc).replace("max_dimension", "max_action_dimension")) from exc
    if quotient.dimension > max_action_dimension:
        raise ActionMatrixError(
            f"quotient dimension exceeds max_action_dimension={max_action_dimension}"
        )
    monomials = quotient.standard_exponents
    dimension = quotient.dimension
    if dimension == 0:
        raise ActionMatrixError("zero-dimensional quotient has empty monomial basis")
    if dimension > max_solutions:
        raise SystemSolveLimitError(f"quotient dimension exceeds max_solutions={max_solutions}")

    coordinate_forms = quotient.coordinate_normal_forms
    last_validation_error: ActionMatrixError | None = None

    for coefficients in _separator_candidates(len(variables)):
        # QuotientAlgebra centralizes the exact quotient reduction.  Its direct
        # separator constructor preserves the previous D-reduction action path.
        try:
            columns = quotient.separator_matrix_columns(coefficients)
        except QuotientAlgebraError as exc:
            raise ActionMatrixError(str(exc)) from exc

        if not flint_available():  # pragma: no cover - development fallback
            try:
                raw = _exact_action_fallback(columns, coordinate_forms, monomials, work_digits)
                roots, diagnostics, max_residual = _validate_roots(
                    raw,
                    normalized,
                    variables,
                    digits=digits,
                    work_digits=work_digits,
                    verification_digits=verification_digits,
                    maxsteps=maxsteps,
                    expected_count=dimension,
                    error_type=ActionMatrixError,
                )
            except ActionMatrixError as exc:
                if quotient.geometric_solution_count < dimension:
                    raise
                last_validation_error = exc
                continue
            return PolynomialSystemRoots(
                roots=roots,
                variables=variables,
                equations=normalized,
                groebner_basis=basis_exprs,
                precision_digits=digits,
                working_digits=work_digits,
                verification_digits=verification_digits,
                max_relative_residual=max_residual,
                method="action_matrix",
                diagnostics=diagnostics,
                quotient_dimension=dimension,
                standard_monomials=monomials,
                separator_coeffs=coefficients,
            )

        max_digits = max_precision_digits or max(work_digits * 4, work_digits + 100)
        current_digits = max(30, work_digits + 5)
        while current_digits <= max_digits:
            with flint_dps(current_digits):
                try:
                    separator = _acb_separator_matrix(columns, current_digits)
                    # The default ACB eigensolver certifies that all eigenvalues
                    # are simple and isolated. Failure triggers a precision retry.
                    eigenvalues, eigenvectors = separator.eig(right=True)
                except (ValueError, ZeroDivisionError):
                    eigenvalues = eigenvectors = None
                if eigenvalues is None or eigenvectors is None or len(eigenvalues) != dimension:
                    if quotient.geometric_solution_count < dimension:
                        raise ActionMatrixError(
                            "nonreduced quotient requires RUR or triangular solving"
                        )
                    current_digits *= 2
                    continue
                try:
                    raw = _coords_from_acb_vectors(
                        eigenvectors, coordinate_forms, monomials, current_digits
                    )
                    roots, diagnostics, max_residual = _validate_roots(
                        raw,
                        normalized,
                        variables,
                        digits=digits,
                        work_digits=max(work_digits, current_digits),
                        verification_digits=verification_digits,
                        maxsteps=maxsteps,
                        expected_count=dimension,
                        error_type=ActionMatrixError,
                    )
                except ActionMatrixError as exc:
                    # A rigorously separated eigensystem can still be too coarse
                    # for coordinate recovery/residual validation. Retry at higher
                    # precision before abandoning this separator.
                    last_validation_error = exc
                    current_digits *= 2
                    continue

                return PolynomialSystemRoots(
                    roots=roots,
                    variables=variables,
                    equations=normalized,
                    groebner_basis=basis_exprs,
                    precision_digits=digits,
                    working_digits=max(work_digits, current_digits),
                    verification_digits=verification_digits,
                    max_relative_residual=max_residual,
                    method="action_matrix",
                    diagnostics=diagnostics,
                    quotient_dimension=dimension,
                    standard_monomials=monomials,
                    separator_coeffs=coefficients,
                )

    if last_validation_error is not None:
        raise ActionMatrixError(
            "all tested separator/precision combinations failed exact root-count "
            "or original-system residual validation"
        ) from last_validation_error
    raise ActionMatrixError(
        "no tested linear form yielded a complete rigorously isolated simple "
        "eigensystem; the ideal may be non-radical or numerically ill-conditioned"
    )


def _candidate_equations(
    basis_exprs: tuple[Any, ...],
    variables: tuple[Any, ...],
    index: int,
) -> list[Any]:
    current = variables[index]
    allowed = set(variables[index:])
    candidates: list[tuple[int, int, int, Any]] = []

    for expression in basis_exprs:
        free = expression.free_symbols
        if current not in free or not free <= allowed:
            continue
        try:
            degree = sp.Poly(
                expression,
                *variables[index:],
                extension=True,
            ).degree(current)
        except (sp.PolynomialError, TypeError, ValueError):
            continue
        if degree > 0:
            candidates.append((degree, len(free), int(sp.count_ops(expression)), expression))

    candidates.sort(key=lambda item: item[:3])
    return [item[3] for item in candidates]


def _solve_univariate_branch(
    expression: Any,
    variable: Any,
    assignment: dict[Any, Any],
    digits: int,
    maxsteps: int,
    max_precision_digits: int | None = None,
) -> list[Any] | None:
    # Use exact midpoint values for already chosen numerical coordinates.
    # Evaluating the whole expression first can round distinct factors into
    # repeated factors before squarefree extraction even begins.
    midpoint_assignment = {
        symbol: sp.sympify(value).xreplace(
            {number: sp.Rational(number) for number in sp.sympify(value).atoms(sp.Float)}
        )
        for symbol, value in assignment.items()
    }
    substituted = expression.subs(midpoint_assignment)
    try:
        polynomial = sp.Poly(substituted, variable, extension=True)
    except sp.PolynomialError:
        return None
    if polynomial.degree() <= 0:
        return None
    return _nroots(polynomial.as_expr(), variable, digits, maxsteps, max_precision_digits)


def _solve_triangular(
    normalized: tuple[Any, ...],
    basis_exprs: tuple[Any, ...],
    variables: tuple[Any, ...],
    *,
    digits: int,
    work_digits: int,
    verification_digits: int,
    maxsteps: int,
    max_solutions: int,
    max_precision_digits: int | None = None,
) -> PolynomialSystemRoots:
    branch_tolerance = sp.Float(10, work_digits) ** (-verification_digits)
    branches: list[dict[Any, Any]] = [{}]

    for index in range(len(variables) - 1, -1, -1):
        variable = variables[index]
        candidates = _candidate_equations(basis_exprs, variables, index)
        if not candidates:
            raise TriangularSolveError(
                f"lex Gröbner basis has no triangular equation for {variable}"
            )

        next_branches: list[dict[Any, Any]] = []
        for assignment in branches:
            roots: list[Any] | None = None
            last_error: NumericalRootError | None = None
            for candidate in candidates:
                try:
                    roots = _solve_univariate_branch(
                        candidate,
                        variable,
                        assignment,
                        work_digits,
                        maxsteps,
                        max_precision_digits,
                    )
                except NumericalRootError as exc:
                    last_error = exc
                    continue
                if roots is not None:
                    break

            if roots is None:
                if last_error is not None:
                    raise last_error
                raise TriangularSolveError(
                    f"triangular equations became degenerate while solving {variable}"
                )

            for root in roots:
                candidate_assignment = dict(assignment)
                candidate_assignment[variable] = sp.N(root, work_digits)
                if _assignment_satisfies(
                    basis_exprs,
                    variables,
                    candidate_assignment,
                    branch_tolerance,
                    work_digits,
                ):
                    next_branches.append(candidate_assignment)

            if len(next_branches) > max_solutions:
                raise SystemSolveLimitError(
                    f"solution branch count exceeds max_solutions={max_solutions}"
                )

        branches = next_branches
        if not branches:
            raise NumericalRootError(
                f"no verified numerical branches remain after solving {variable}"
            )

    candidates = [tuple(assignment[variable] for variable in variables) for assignment in branches]
    roots, diagnostics, max_residual = _validate_roots(
        candidates,
        normalized,
        variables,
        digits=digits,
        work_digits=work_digits,
        verification_digits=verification_digits,
        maxsteps=maxsteps,
        expected_count=None,
        error_type=NumericalRootError,
    )
    if len(roots) > max_solutions:
        raise SystemSolveLimitError(f"solution count exceeds max_solutions={max_solutions}")

    return PolynomialSystemRoots(
        roots=roots,
        variables=variables,
        equations=normalized,
        groebner_basis=basis_exprs,
        precision_digits=digits,
        working_digits=work_digits,
        verification_digits=verification_digits,
        max_relative_residual=max_residual,
        method="triangular_groebner",
        diagnostics=diagnostics,
    )


def _root_sort_key(root: tuple[Any, ...]) -> tuple[float, ...]:
    key: list[float] = []
    for value in root:
        numeric = sp.N(value, 17)
        key.extend((float(sp.re(numeric)), float(sp.im(numeric))))
    return tuple(key)


def _roots_close(
    left: tuple[Any, ...],
    right: tuple[Any, ...],
    tolerance: Any,
    *,
    comparison_digits: int = 30,
) -> bool:
    """Compare coordinates relative to their own magnitudes, without a unit floor."""
    return all(
        abs(sp.N(a - b, comparison_digits))
        <= tolerance * max(abs(sp.N(a, comparison_digits)), abs(sp.N(b, comparison_digits)))
        for a, b in zip(left, right, strict=True)
    )


def _validate_options(
    digits: int,
    verification_digits: int | None,
    guard_digits: int,
    maxsteps: int,
    max_solutions: int,
    max_action_dimension: int,
    max_precision_digits: int | None,
    method: SolveMethod,
    recognize: bool,
    recognition_max_degree: int,
) -> int:
    validate_integer(digits, "digits", minimum=15)
    if verification_digits is None:
        verification_digits = max(10, digits // 2)
    validate_integer(verification_digits, "verification_digits")
    if verification_digits >= digits:
        raise ValueError("verification_digits must be an integer in [1, digits)")
    validate_integer(guard_digits, "guard_digits", minimum=0)
    for value, name in (
        (maxsteps, "maxsteps"),
        (max_solutions, "max_solutions"),
        (max_action_dimension, "max_action_dimension"),
    ):
        validate_integer(value, name)
    if max_precision_digits is not None:
        validate_integer(max_precision_digits, "max_precision_digits", minimum=digits)
    if method not in {"auto", "shape", "action", "triangular", "rur", "homotopy"}:
        raise ValueError(
            "method must be 'auto', 'shape', 'action', 'triangular', 'rur', or 'homotopy'"
        )
    validate_recognition_options(recognize, recognition_max_degree)
    return verification_digits


@dataclass(frozen=True)
class _PreparedHomotopyProblem:
    base: TotalDegreeHomotopy
    tracker_options: PathTrackerOptions
    compiled_system: _CompiledPolynomialSystem


def _prepare_total_degree_problem(
    normalized: tuple[Any, ...],
    variables: tuple[Any, ...],
    *,
    work_digits: int,
    verification_digits: int,
    maxsteps: int,
    max_precision_digits: int | None,
    options: TotalDegreeHomotopyOptions,
) -> _PreparedHomotopyProblem:
    if len(normalized) != len(variables):
        raise HomotopySolveError("total-degree homotopy requires a square polynomial system")
    base = build_total_degree_homotopy(
        normalized,
        variables,
        seed=options.seed,
        max_paths=options.max_paths,
    )
    default_initial_digits = max(35, work_digits)
    initial_digits = (
        min(default_initial_digits, max_precision_digits)
        if max_precision_digits is not None
        else default_initial_digits
    )
    tracker = PathTrackerOptions(
        initial_digits=initial_digits,
        max_digits=max_precision_digits or max(work_digits * 4, work_digits + 100),
        residual_digits=verification_digits,
        max_steps=max(4000, maxsteps),
        max_newton_steps=max(8, min(maxsteps, 50)),
    )
    return _PreparedHomotopyProblem(
        base=base,
        tracker_options=tracker,
        compiled_system=_CompiledPolynomialSystem.build(normalized, variables),
    )


def _track_total_degree_problem(
    problem: _PreparedHomotopyProblem,
    gamma: Any,
    options: TotalDegreeHomotopyOptions,
) -> tuple[PathResult, ...]:
    return track_total_degree_paths(
        problem.base.with_gamma(gamma),
        options=problem.tracker_options,
        parallel=options.parallel,
        max_workers=options.max_workers,
    )


def _resolve_endpoint_regularity(
    candidate: tuple[Any, ...],
    compiled: _CompiledPolynomialSystem,
    *,
    start_digits: int,
    max_digits: int,
    verification_digits: int,
    maxsteps: int,
) -> tuple[tuple[Any, ...], _EndpointRegularity]:
    """Re-refine an endpoint until nonsingularity is numerically resolved.

    Very small singular values are evaluated at successively higher precision.
    A genuine small-but-nonzero singular value stabilizes, while an apparent
    singular value caused by an endpoint converging to a multiple root shrinks
    with the refinement precision.
    """
    digits = min(max_digits, max(30, start_digits))
    values = _mp_root(candidate, digits + 8)
    previous_smallest: mp.mpf | None = None
    suspicion_threshold = mp.power(10, -max(6, verification_digits // 2))
    while True:
        refined, _ = newton_refine(
            compiled.polynomials,
            compiled.jacobian,
            values,
            digits,
            maxsteps,
        )
        candidate_sp = _sp_root(refined, digits)
        regularity = compiled.endpoint_regularity(
            candidate_sp,
            digits=digits,
            verification_digits=verification_digits,
        )
        smallest = regularity.smallest_singular_value
        if regularity.resolved and smallest > suspicion_threshold:
            return candidate_sp, regularity
        if (
            previous_smallest is not None
            and smallest > 0
            and previous_smallest > 0
            and mp.isfinite(smallest)
            and mp.isfinite(previous_smallest)
        ):
            ratio = max(smallest, previous_smallest) / min(smallest, previous_smallest)
            if ratio <= mp.mpf(100):
                return candidate_sp, _EndpointRegularity(
                    smallest,
                    regularity.condition_estimate,
                    digits,
                    True,
                )
        if digits >= max_digits:
            return candidate_sp, _EndpointRegularity(
                smallest,
                regularity.condition_estimate,
                digits,
                False,
            )
        previous_smallest = smallest
        next_digits = min(max_digits, max(digits + 20, digits * 2))
        if next_digits <= digits:
            return candidate_sp, regularity
        values = refined
        digits = next_digits


def _validate_homotopy_endpoints(
    paths: tuple[PathResult, ...],
    normalized: tuple[Any, ...],
    variables: tuple[Any, ...],
    *,
    digits: int,
    work_digits: int,
    verification_digits: int,
    maxsteps: int,
    max_precision_digits: int | None,
    compiled_system: _CompiledPolynomialSystem,
) -> tuple[
    tuple[tuple[Any, ...], ...],
    tuple[RootDiagnostics, ...],
    Any,
    tuple[_EndpointRegularity, ...],
]:
    max_digits = max_precision_digits or max(work_digits * 4, work_digits + 100)
    candidates: list[tuple[Any, ...]] = []
    regularities: list[_EndpointRegularity] = []
    for path in paths:
        candidate, regularity = _resolve_endpoint_regularity(
            tuple(path.endpoint),
            compiled_system,
            start_digits=max(work_digits, path.final_digits),
            max_digits=max_digits,
            verification_digits=verification_digits,
            maxsteps=maxsteps,
        )
        if not regularity.resolved:
            raise HomotopySolveError(
                "total-degree homotopy reached a singular or numerically unresolved "
                "endpoint; use the explicit Cauchy endgame and exact certificate APIs"
            )
        candidates.append(candidate)
        regularities.append(regularity)
    roots, diagnostics, max_residual = _validate_roots(
        candidates,
        normalized,
        variables,
        digits=digits,
        work_digits=max(
            work_digits,
            max((r.digits for r in regularities), default=work_digits),
        ),
        verification_digits=verification_digits,
        maxsteps=maxsteps,
        expected_count=len(paths),
        error_type=HomotopySolveError,
        compiled_system=compiled_system,
    )
    tolerance = sp.Float(10, digits) ** (-digits)
    comparison_digits = max(30, digits + 10)
    unused = set(range(len(candidates)))
    aligned: list[_EndpointRegularity] = []
    for root in roots:
        match = next(
            (
                index
                for index in unused
                if _roots_close(
                    root,
                    candidates[index],
                    tolerance,
                    comparison_digits=comparison_digits,
                )
            ),
            None,
        )
        if match is None:  # pragma: no cover - guarded by equal-count validation
            raise HomotopySolveError(
                "homotopy endpoint diagnostics could not be aligned with roots"
            )
        unused.remove(match)
        aligned.append(regularities[match])
    return roots, diagnostics, max_residual, tuple(aligned)


def _solve_total_degree_homotopy(
    normalized: tuple[Any, ...],
    variables: tuple[Any, ...],
    *,
    digits: int,
    work_digits: int,
    verification_digits: int,
    maxsteps: int,
    max_solutions: int,
    max_precision_digits: int | None,
    homotopy_options: TotalDegreeHomotopyOptions,
) -> PolynomialSystemRoots:
    # A nonzero constant equation makes the affine system inconsistent and
    # requires no path tracking. An identically zero equation is rejected by
    # the constructor because it falls outside the regular square-system scope.
    for equation in normalized:
        polynomial = sp.Poly(equation, *variables, extension=True)
        if not polynomial.is_zero and polynomial.total_degree() == 0:
            return PolynomialSystemRoots(
                roots=(),
                variables=variables,
                equations=normalized,
                groebner_basis=(),
                precision_digits=digits,
                working_digits=work_digits,
                verification_digits=verification_digits,
                max_relative_residual=sp.Integer(0),
                method="total_degree_homotopy",
                homotopy_paths_total=0,
                homotopy_paths_succeeded=0,
                homotopy_paths_failed=0,
                homotopy_paths_divergent=0,
                homotopy_gamma_attempts=0,
            )

    problem = _prepare_total_degree_problem(
        normalized,
        variables,
        work_digits=work_digits,
        verification_digits=verification_digits,
        maxsteps=maxsteps,
        max_precision_digits=max_precision_digits,
        options=homotopy_options,
    )
    path_count = problem.base.path_count
    if path_count > max_solutions:
        raise SystemSolveLimitError(
            f"total-degree homotopy path count exceeds max_solutions={max_solutions}"
        )

    failures: list[str] = []
    for attempt, gamma in enumerate(
        gamma_candidates(homotopy_options.seed, homotopy_options.gamma_attempts),
        start=1,
    ):
        paths = _track_total_degree_problem(problem, gamma, homotopy_options)
        failed = tuple(path for path in paths if not path.success)
        divergent = tuple(path for path in failed if path.classification == "likely_divergent")
        if failed:
            messages = sorted({path.message for path in failed if path.message})
            detail = messages[0] if messages else "path tracking failed"
            failures.append(
                f"gamma attempt {attempt}: {len(failed)}/{path_count} paths failed "
                f"({len(divergent)} likely divergent); {detail}"
            )
            continue
        try:
            roots, diagnostics, max_residual, regularities = _validate_homotopy_endpoints(
                paths,
                normalized,
                variables,
                digits=digits,
                work_digits=work_digits,
                verification_digits=verification_digits,
                maxsteps=maxsteps,
                max_precision_digits=max_precision_digits,
                compiled_system=problem.compiled_system,
            )
        except HomotopySolveError as exc:
            if "expected number of distinct roots" not in str(exc):
                failures.append(f"gamma attempt {attempt}: {exc}")
                continue
            # Newton may jump between nearby paths at an overly large step.
            # Retry the same gamma with a stricter step cap; never accept the
            # duplicate endpoints merely because their residuals are small.
            smaller = replace(
                problem,
                tracker_options=replace(
                    problem.tracker_options,
                    initial_step=problem.tracker_options.initial_step / 2,
                    max_step=problem.tracker_options.max_step / 4,
                ),
            )
            paths = _track_total_degree_problem(smaller, gamma, homotopy_options)
            if any(not path.success for path in paths):
                failures.append(
                    f"gamma attempt {attempt}: smaller-step tracking failed after {exc}"
                )
                continue
            try:
                roots, diagnostics, max_residual, regularities = _validate_homotopy_endpoints(
                    paths,
                    normalized,
                    variables,
                    digits=digits,
                    work_digits=work_digits,
                    verification_digits=verification_digits,
                    maxsteps=maxsteps,
                    max_precision_digits=max_precision_digits,
                    compiled_system=problem.compiled_system,
                )
            except HomotopySolveError as retry_exc:
                failures.append(f"gamma attempt {attempt}: {retry_exc}")
                continue
        return PolynomialSystemRoots(
            roots=roots,
            variables=variables,
            equations=normalized,
            groebner_basis=(),
            precision_digits=digits,
            working_digits=max(
                [
                    work_digits,
                    *(path.final_digits for path in paths),
                    *(r.digits for r in regularities),
                ]
            ),
            verification_digits=verification_digits,
            max_relative_residual=max_residual,
            method="total_degree_homotopy",
            diagnostics=diagnostics,
            homotopy_paths_total=path_count,
            homotopy_paths_succeeded=len(paths),
            homotopy_paths_failed=0,
            homotopy_paths_divergent=0,
            homotopy_gamma=gamma,
            homotopy_gamma_attempts=attempt,
            homotopy_endpoint_smallest_singular_values=tuple(
                sp.Float(mp.nstr(r.smallest_singular_value, max(20, digits)), digits)
                for r in regularities
            ),
            homotopy_endpoint_condition_estimates=tuple(
                sp.Float(mp.nstr(r.condition_estimate, max(20, digits)), digits)
                if mp.isfinite(r.condition_estimate)
                else sp.oo
                for r in regularities
            ),
        )

    detail = "; ".join(failures[:3])
    raise HomotopySolveError(
        "total-degree homotopy failed for every deterministic gamma candidate"
        + (f": {detail}" if detail else "")
        + ". High-level singular/infinite path orchestration remains unsupported; explicit endgame/projective APIs are available."
    )


def _solve_rur(
    normalized: tuple[Any, ...],
    variables: tuple[Any, ...],
    *,
    digits: int,
    work_digits: int,
    verification_digits: int,
    maxsteps: int,
    max_solutions: int,
    quotient: QuotientAlgebra | None = None,
    max_precision_digits: int | None = None,
) -> PolynomialSystemRoots:
    from .rational_univariate import compute_rational_univariate_representation
    from .rational_univariate.construction import rur_from_quotient
    from .rational_univariate.solve import numerical_rur_roots

    representation = (
        rur_from_quotient(quotient)
        if quotient is not None
        else compute_rational_univariate_representation(normalized, variables)
    )
    if representation.solution_count > max_solutions:
        raise SystemSolveLimitError(f"RUR solution count exceeds max_solutions={max_solutions}")
    candidates = list(
        numerical_rur_roots(
            representation,
            digits=work_digits,
            maxsteps=max(100, maxsteps),
            max_precision_digits=max_precision_digits,
        )
    )
    roots, diagnostics, max_residual = _validate_roots(
        candidates,
        normalized,
        variables,
        digits=digits,
        work_digits=work_digits,
        verification_digits=verification_digits,
        maxsteps=maxsteps,
        expected_count=representation.solution_count,
        error_type=NumericalRootError,
    )
    return PolynomialSystemRoots(
        roots=roots,
        variables=variables,
        equations=normalized,
        groebner_basis=(),
        precision_digits=digits,
        working_digits=work_digits,
        verification_digits=verification_digits,
        max_relative_residual=max_residual,
        method="rational_univariate",
        diagnostics=diagnostics,
        quotient_dimension=representation.quotient_dimension,
        standard_monomials=representation.standard_exponents,
        rational_univariate_representation=representation,
    )


def _polysolve(
    equations: Iterable[Any],
    variables: Sequence[Any],
    *,
    digits: int = 50,
    verification_digits: int | None = None,
    guard_digits: int = 10,
    maxsteps: int = 200,
    max_solutions: int = 10_000,
    max_action_dimension: int = 256,
    max_precision_digits: int | None = None,
    method: SolveMethod = "auto",
    recognize: bool = True,
    recognition_max_degree: int = 8,
    max_homotopy_paths: int = 10_000,
    homotopy_seed: int = 0,
    homotopy_gamma_attempts: int = 4,
    homotopy_parallel: bool = False,
    homotopy_max_workers: int | None = None,
) -> PolynomialSystemRoots:
    """Find all distinct numerical roots of an exact zero-dimensional system.

    ``method="auto"`` first uses shape position when available, then an
    action-matrix quotient-algebra solver, and finally triangular
    back-substitution when the action backend declines. ``method="shape"``
    requires shape position; ``method="action"`` requires a regular separated
    action-matrix solve. ``method="rur"`` uses an exact rational univariate
    representation over `QQ` or an exact algebraic number field.
    ``method="homotopy"`` explicitly selects total-degree homotopy continuation
    for regular square systems whose Bézout paths have finite nonsingular
    endpoints. It is not selected by ``method="auto"``.

    Exact algebraic recognition is attempted by default after the numerical
    solve. Successfully recognized roots are stored in ``recognized_roots``.
    Recognition failure does not invalidate an otherwise verified numerical
    solve; the failure is recorded in ``recognition_error``. Pass
    ``recognize=False`` to skip recognition entirely.

    Equations may be polynomial expressions interpreted as ``expr == 0`` or
    SymPy ``Eq`` objects. Coefficients must be exact algebraic numbers.
    """
    quotient = None
    phase_times = {}
    estimates = {}

    def finish(result: PolynomialSystemRoots) -> PolynomialSystemRoots:
        from .recognition import _auto_recognize

        result = replace(
            result,
            cost_diagnostics=SolveCostDiagnostics(
                tuple(phase_times.items()),
                tuple(
                    dict(
                        estimates,
                        selected_backend=result.method,
                        variables=len(variables),
                        quotient_dimension=quotient.dimension if quotient is not None else None,
                    ).items()
                ),
                tuple(quotient.normal_form_cache_info.items()) if quotient is not None else (),
                quotient_operation_statistics=tuple(quotient.operation_diagnostics.items())
                if quotient is not None
                else (),
            ),
        )
        if result.method != "total_degree_homotopy":
            dimension = quotient.dimension if quotient is not None else 0
            if quotient is None:
                geometric = 0
                count_basis = "unit_ideal"
            elif result.rational_univariate_representation is not None:
                geometric = result.rational_univariate_representation.solution_count
                count_basis = "exact_rur_geometric_count"
            elif result.eliminant is not None:
                geometric = (
                    sp.Poly(result.eliminant, result.parameter_variable, extension=True)
                    .sqf_part()
                    .degree()
                )
                count_basis = "squarefree_shape_eliminant"
            elif result.method == "action_matrix":
                geometric = dimension
                count_basis = "simple_quotient_eigensystem"
            else:
                geometric = quotient.geometric_solution_count
                count_basis = "exact_trace_pairing_rank"
            if geometric != len(result.roots):
                raise NumericalRootError(
                    "returned distinct roots disagree with exact geometric count"
                )
            result = replace(
                result,
                quotient_dimension=dimension,
                total_multiplicity=dimension,
                geometric_solution_count=geometric,
                is_radical=dimension == geometric,
                has_multiple_roots=dimension > geometric,
                solver_variables=variables,
                completeness=CompletenessEvidence(
                    "certified" if geometric == 0 else "conditional",
                    count_basis,
                    geometric,
                    geometric,
                    dimension,
                    (
                        "Exact enumeration count; coordinates are numerically verified, not exact certificates.",
                    ),
                ),
            )
        else:
            result = replace(
                result,
                completeness=CompletenessEvidence(
                    "numerical",
                    "total_degree_path_accounting",
                    result.homotopy_paths_total,
                    len(result.roots),
                    notes=("Finite regular endpoints only; no rigorous path enclosure.",),
                ),
            )

        return _auto_recognize(result, recognize=recognize, max_degree=recognition_max_degree)

    verification_digits = _validate_options(
        digits,
        verification_digits,
        guard_digits,
        maxsteps,
        max_solutions,
        max_action_dimension,
        max_precision_digits,
        method,
        recognize,
        recognition_max_degree,
    )
    homotopy_options = TotalDegreeHomotopyOptions(
        max_paths=max_homotopy_paths,
        seed=homotopy_seed,
        parallel=homotopy_parallel,
        max_workers=homotopy_max_workers,
        gamma_attempts=homotopy_gamma_attempts,
    )
    variables = validate_variables(variables)
    normalized = _normalize_equations(equations, variables)
    work_digits = digits + guard_digits
    if method == "homotopy":
        return finish(
            _solve_total_degree_homotopy(
                normalized,
                variables,
                digits=digits,
                work_digits=work_digits,
                verification_digits=verification_digits,
                maxsteps=maxsteps,
                max_solutions=max_solutions,
                max_precision_digits=max_precision_digits,
                homotopy_options=homotopy_options,
            )
        )
    phase_started = perf_counter()
    basis = _groebner_basis(normalized, variables)
    phase_times["solve.groebner"] = perf_counter() - phase_started
    basis_exprs = tuple(poly.as_expr() for poly in basis.polys)

    if _is_unit_ideal(basis) and method == "rur":
        quotient = QuotientAlgebra.from_groebner_basis(basis, variables)
        return finish(
            _solve_rur(
                normalized,
                variables,
                digits=digits,
                work_digits=work_digits,
                verification_digits=verification_digits,
                maxsteps=maxsteps,
                max_solutions=max_solutions,
                quotient=quotient,
                max_precision_digits=max_precision_digits,
            )
        )

    if _is_unit_ideal(basis):
        result = PolynomialSystemRoots(
            roots=(),
            variables=variables,
            equations=normalized,
            groebner_basis=basis_exprs,
            precision_digits=digits,
            working_digits=digits + guard_digits,
            verification_digits=verification_digits,
            max_relative_residual=sp.Integer(0),
            method="shape_position" if method == "shape" else "triangular_groebner",
        )
        return finish(result)

    if not basis.is_zero_dimensional:
        raise NotZeroDimensionalError("the polynomial system is not zero-dimensional")

    quotient = QuotientAlgebra.from_groebner_basis(basis, variables)
    if method == "rur":
        return finish(
            _solve_rur(
                normalized,
                variables,
                digits=digits,
                work_digits=work_digits,
                verification_digits=verification_digits,
                maxsteps=maxsteps,
                max_solutions=max_solutions,
                quotient=quotient,
                max_precision_digits=max_precision_digits,
            )
        )
    if method in {"shape", "triangular"}:
        basis = basis.fglm(order="lex")
        basis_exprs = tuple(poly.as_expr() for poly in basis.polys)

    representation = _shape_representation(basis_exprs, variables)
    if method in {"auto", "shape"} and representation is not None:
        result = _solve_shape(
            representation,
            normalized,
            basis_exprs,
            variables,
            digits=digits,
            work_digits=work_digits,
            verification_digits=verification_digits,
            maxsteps=maxsteps,
            max_solutions=max_solutions,
            max_precision_digits=max_precision_digits,
        )
        return finish(result)

    if method == "shape":
        raise ShapePositionError("the lex Gröbner basis is not in supported shape position")

    from .cost_policy import prefer_action

    action_preferred, estimates = prefer_action(
        quotient, min(max_action_dimension, max_solutions), normalized
    )
    if method == "action" or (method == "auto" and action_preferred):
        try:
            result = _solve_action_matrix(
                normalized,
                basis,
                basis_exprs,
                variables,
                digits=digits,
                work_digits=work_digits,
                verification_digits=verification_digits,
                maxsteps=maxsteps,
                max_solutions=max_solutions,
                max_action_dimension=max_action_dimension,
                quotient=quotient,
                max_precision_digits=max_precision_digits,
            )
            return finish(result)
        except ActionMatrixError:
            if method == "action":
                raise

    if method == "auto":
        from .rational_univariate import RationalUnivariateError

        try:
            return finish(
                _solve_rur(
                    normalized,
                    variables,
                    digits=digits,
                    work_digits=work_digits,
                    verification_digits=verification_digits,
                    maxsteps=maxsteps,
                    max_solutions=max_solutions,
                    quotient=quotient,
                    max_precision_digits=max_precision_digits,
                )
            )
        except RationalUnivariateError:
            if not action_preferred and quotient.dimension <= min(
                64, max_action_dimension, max_solutions
            ):
                try:
                    return finish(
                        _solve_action_matrix(
                            normalized,
                            basis,
                            basis_exprs,
                            variables,
                            digits=digits,
                            work_digits=work_digits,
                            verification_digits=verification_digits,
                            maxsteps=maxsteps,
                            max_solutions=max_solutions,
                            max_action_dimension=max_action_dimension,
                            quotient=quotient,
                            max_precision_digits=max_precision_digits,
                        )
                    )
                except ActionMatrixError:
                    pass
        basis = basis.fglm(order="lex")
        basis_exprs = tuple(poly.as_expr() for poly in basis.polys)

    result = _solve_triangular(
        normalized,
        basis_exprs,
        variables,
        digits=digits,
        work_digits=work_digits,
        verification_digits=verification_digits,
        maxsteps=maxsteps,
        max_solutions=max_solutions,
        max_precision_digits=max_precision_digits,
    )
    return finish(result)


def polysolve(
    equations: Iterable[Any],
    variables: Sequence[Any],
    *,
    digits: int = 50,
    verification_digits: int | None = None,
    guard_digits: int = 10,
    maxsteps: int = 200,
    max_solutions: int = 10_000,
    max_action_dimension: int = 256,
    max_precision_digits: int | None = None,
    method: SolveMethod = "auto",
    recognize: bool = True,
    recognition_max_degree: int = 8,
    max_homotopy_paths: int = 10_000,
    homotopy_seed: int = 0,
    homotopy_gamma_attempts: int = 4,
    homotopy_parallel: bool = False,
    homotopy_max_workers: int | None = None,
    presolve: bool = True,
    variable_order: str = "auto",
    presolve_max_terms: int = 1000,
    presolve_max_degree: int = 16,
    presolve_growth_factor: int = 4,
    certify: bool | str = False,
    certification_max_dimension: int = 128,
    certification_max_refinements: int = 128,
    certification_max_box_attempts: int = 16,
    homotopy_recovery: bool = False,
    recovery_options: Any | None = None,
    root_mode: str = "distinct",
    multiplicity: bool | str = "auto",
    root_order: str = "canonical",
    max_returned_roots: int = 10_000,
    ordering_max_refinements: int = 64,
) -> PolynomialSystemRoots:
    """Solve exact finite systems with affine presolve and a lazy grevlex portfolio.

    ``presolve=False`` preserves every input variable in the quotient.
    ``variable_order="auto"`` deterministically sorts remaining variables by
    occurrence count then degree, using minimum-fill ordering when its graph
    cost is strictly lower; public coordinates keep the supplied order.
    Other keyword controls are documented by ``_polysolve``.
    """
    validate_output_options(
        root_mode, multiplicity, root_order, max_returned_roots, ordering_max_refinements
    )
    output_options = dict(
        root_mode=root_mode,
        multiplicity=multiplicity,
        root_order=root_order,
        max_returned_roots=max_returned_roots,
        ordering_max_refinements=ordering_max_refinements,
        certification_max_dimension=certification_max_dimension,
        certification_max_refinements=certification_max_refinements,
        certification_max_box_attempts=certification_max_box_attempts,
    )
    total_started = perf_counter()
    timings = {}
    phase_started = perf_counter()
    verification_digits = _validate_options(
        digits,
        verification_digits,
        guard_digits,
        maxsteps,
        max_solutions,
        max_action_dimension,
        max_precision_digits,
        method,
        recognize,
        recognition_max_degree,
    )
    options = dict(locals())
    for name in (
        "root_mode",
        "multiplicity",
        "root_order",
        "max_returned_roots",
        "ordering_max_refinements",
        "output_options",
        "equations",
        "variables",
        "presolve",
        "variable_order",
        "presolve_max_terms",
        "presolve_max_degree",
        "presolve_growth_factor",
        "certify",
        "certification_max_dimension",
        "certification_max_refinements",
        "certification_max_box_attempts",
        "homotopy_recovery",
        "recovery_options",
        "total_started",
        "timings",
        "phase_started",
    ):
        options.pop(name)
    from .certification import _positive_integer, certify_numerical_roots
    from .presolve import affine_presolve, polynomial_presolve

    if not isinstance(certify, bool) and not (
        isinstance(certify, str) and certify in ("auto", "required")
    ):
        raise PolynomialSystemInputError("certify must be False, True, auto or required")
    for value, name in (
        (presolve_max_terms, "presolve_max_terms"),
        (presolve_max_degree, "presolve_max_degree"),
        (presolve_growth_factor, "presolve_growth_factor"),
        (certification_max_dimension, "certification_max_dimension"),
        (certification_max_refinements, "certification_max_refinements"),
        (certification_max_box_attempts, "certification_max_box_attempts"),
    ):
        _positive_integer(value, name)

    if not isinstance(presolve, bool):
        raise PolynomialSystemInputError("presolve must be Boolean")
    if variable_order not in {"input", "auto"}:
        raise PolynomialSystemInputError("variable_order must be input or auto")
    original_variables = validate_variables(variables)
    normalized = _normalize_equations(equations, original_variables)
    timings["input"] = perf_counter() - phase_started
    if not isinstance(homotopy_recovery, bool):
        raise PolynomialSystemInputError("homotopy_recovery must be Boolean")
    if recovery_options is not None and not homotopy_recovery:
        raise PolynomialSystemInputError("recovery_options requires homotopy_recovery=True")
    if homotopy_recovery:
        if method != "homotopy":
            raise PolynomialSystemInputError("homotopy_recovery requires method=homotopy")
        if homotopy_parallel:
            raise PolynomialSystemInputError("bounded recovery currently runs sequentially")
        TotalDegreeHomotopyOptions(
            max_paths=max_homotopy_paths,
            seed=homotopy_seed,
            parallel=homotopy_parallel,
            max_workers=homotopy_max_workers,
            gamma_attempts=homotopy_gamma_attempts,
        )
        from .recovery import solve_recovered_homotopy

        result = solve_recovered_homotopy(
            normalized,
            original_variables,
            digits=digits,
            guard_digits=guard_digits,
            verification_digits=verification_digits,
            maxsteps=maxsteps,
            max_solutions=max_solutions,
            max_paths=max_homotopy_paths,
            seed=homotopy_seed,
            options=recovery_options,
            max_precision_digits=max_precision_digits,
            certification_max_dimension=certification_max_dimension,
            certification_max_refinements=certification_max_refinements,
            certification_max_box_attempts=certification_max_box_attempts,
            gamma_attempts=homotopy_gamma_attempts,
        )
        from .recognition import _auto_recognize

        result = _auto_recognize(result, recognize=recognize, max_degree=recognition_max_degree)
        result = replace(
            result,
            cost_diagnostics=SolveCostDiagnostics(
                (("total", perf_counter() - total_started),),
                (("paths_attempted", len(result.recovery_records)),),
                normal_form_statistics=result.cost_diagnostics.normal_form_statistics,
                quotient_operation_statistics=result.cost_diagnostics.quotient_operation_statistics,
            ),
        )
        return finish_root_output(result, **output_options)
    phase_started = perf_counter()
    # The continuation backend retains its square-system contract.
    if options.get("method") == "homotopy" or not presolve:
        reduced = affine_presolve((), original_variables)
        reduced = replace(reduced, equations=normalized)
    else:
        reduced = polynomial_presolve(
            normalized,
            original_variables,
            max_terms=presolve_max_terms,
            max_degree=presolve_max_degree,
            growth_factor=presolve_growth_factor,
        )
    solve_variables = reduced.variables
    if variable_order == "auto" and solve_variables:
        from .cost_policy import ordered_variables

        solve_variables = ordered_variables(reduced.equations, solve_variables)
    timings["presolve_and_ordering"] = perf_counter() - phase_started
    phase_started = perf_counter()
    if reduced.inconsistent or not solve_variables:
        # A dummy coordinate keeps option validation and empty/point solving uniform.
        dummy = sp.Dummy("affine_point")
        result = _polysolve(
            (sp.Integer(1),) if reduced.inconsistent else (dummy,),
            (dummy,),
            **dict(options, recognize=False),
        )
        candidates = (
            []
            if reduced.inconsistent
            else [reduced.reconstruct((), original_variables, result.working_digits)]
        )
    else:
        result = _polysolve(
            reduced.equations or (sp.Integer(0),), solve_variables, **dict(options, recognize=False)
        )
        candidates = [
            reduced.reconstruct(
                tuple(root[solve_variables.index(v)] for v in reduced.variables),
                original_variables,
                result.working_digits,
            )
            for root in result.roots
        ]
    timings["solve"] = perf_counter() - phase_started
    phase_started = perf_counter()
    roots, diagnostics, residual = _validate_roots(
        candidates,
        normalized,
        original_variables,
        digits=result.precision_digits,
        work_digits=result.working_digits,
        verification_digits=result.verification_digits,
        maxsteps=options.get("maxsteps", 200),
        expected_count=len(result.roots),
    )
    # Original-coordinate reconstruction can change the lexicographic order.
    # Track its source indices before any per-root endpoint metadata is copied.
    endpoint_updates = {}
    if any(
        getattr(result, name) is not None
        for name in (
            "homotopy_endpoint_smallest_singular_values",
            "homotopy_endpoint_condition_estimates",
        )
    ):
        remaining_indices = set(range(len(candidates)))
        source_indices = []
        for root in roots:
            index = min(
                remaining_indices,
                key=lambda i: sum(
                    abs(sp.N(a - b, result.working_digits))
                    for a, b in zip(root, candidates[i], strict=True)
                ),
            )
            source_indices.append(index)
            remaining_indices.remove(index)
        endpoint_updates = {
            name: tuple(getattr(result, name)[i] for i in source_indices)
            for name in (
                "homotopy_endpoint_smallest_singular_values",
                "homotopy_endpoint_condition_estimates",
            )
            if getattr(result, name) is not None
        }
    representation = result.rational_univariate_representation
    if representation is not None and representation.variables != original_variables:
        coordinate_map = dict(
            zip(
                representation.variables,
                (poly.as_expr() for poly in representation.normalized_coordinate_polynomials()),
                strict=True,
            )
        )
        for variable, expression in reversed(reduced.substitutions):
            coordinate_map[variable] = sp.expand(expression.subs(coordinate_map))
        numerators = tuple(
            sp.Poly(
                coordinate_map.get(v, 0) if representation.is_empty else coordinate_map[v],
                representation.parameter,
                extension=True,
            ).rem(representation.defining_polynomial)
            for v in original_variables
        )
        # Staircase exponents remain in solver_variables; the lifted RUR exposes
        # original coordinates and a denominator-free exact reconstruction.
        representation = replace(
            representation,
            variables=original_variables,
            standard_exponents=representation.standard_exponents
            if solve_variables
            else (((),) if result.roots else ()),
            separating_linear_form=representation.separating_linear_form
            if solve_variables
            else sp.Integer(0),
            coordinate_numerators=numerators,
            coordinate_denominator=sp.Poly(
                1, representation.parameter, domain=representation.defining_polynomial.domain
            ),
        )
    result = replace(
        result,
        roots=roots,
        **endpoint_updates,
        diagnostics=diagnostics,
        max_relative_residual=residual,
        variables=original_variables,
        equations=normalized,
        solver_variables=solve_variables,
        groebner_basis=result.groebner_basis if solve_variables else (),
        standard_monomials=result.standard_monomials
        if solve_variables
        else (((),) if result.roots else ()),
        affine_substitutions=reduced.substitutions,
        rational_univariate_representation=representation,
    )
    timings["reconstruction_and_validation"] = perf_counter() - phase_started
    phase_started = perf_counter()
    from .recognition import _auto_recognize

    result = _auto_recognize(
        result,
        recognize=options.get("recognize", True),
        max_degree=options.get("recognition_max_degree", 8),
    )
    timings["recognition"] = perf_counter() - phase_started
    phase_started = perf_counter()
    if certify:
        result = replace(
            result,
            root_certifications=certify_numerical_roots(
                result,
                max_quotient_dimension=certification_max_dimension,
                max_refinements=certification_max_refinements,
                required=certify == "required",
                max_box_attempts=certification_max_box_attempts,
            ),
        )
    timings["certification"] = perf_counter() - phase_started
    timings["total"] = perf_counter() - total_started
    base_cost = result.cost_diagnostics or SolveCostDiagnostics()
    result = replace(
        result,
        cost_diagnostics=replace(
            base_cost,
            phase_seconds=base_cost.phase_seconds + tuple(timings.items()),
            structural_estimates=base_cost.structural_estimates
            + (
                ("presolve_cancellation_probes", reduced.cancellation_probes),
                ("presolve_cancellation_acceptances", reduced.cancellation_acceptances),
            ),
        ),
    )

    return finish_root_output(result, **output_options)
