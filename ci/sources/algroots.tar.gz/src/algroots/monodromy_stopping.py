"""Trace and statistical stopping diagnostics for monodromy orbit discovery."""

from __future__ import annotations

import math
from collections.abc import Sequence
from dataclasses import dataclass
from statistics import NormalDist
from typing import Any

import mpmath as mp
import sympy as sp


@dataclass(frozen=True)
class CaptureRecaptureEstimate:
    """Chapman-corrected two-sample capture-recapture estimate."""

    estimate: float
    standard_deviation: float
    lower: float
    upper: float
    confidence: float
    marked: int
    captured: int
    recaptured: int


def capture_recapture_estimate(
    marked: int,
    captured: int,
    recaptured: int,
    *,
    confidence: float = 0.95,
) -> CaptureRecaptureEstimate:
    """Estimate orbit population size from one mark/recapture experiment.

    The Chapman estimator is used instead of the raw Lincoln-Petersen ratio to
    reduce small-sample bias. The interval is a normal approximation based on
    the standard Chapman variance formula and is therefore statistical, not an
    exact completeness certificate.
    """
    if marked <= 0 or captured <= 0:
        raise ValueError("marked and captured counts must be positive")
    if not 0 <= recaptured <= min(marked, captured):
        raise ValueError("recaptured must lie between 0 and both sample sizes")
    if not 0 < confidence < 1:
        raise ValueError("confidence must lie in (0, 1)")

    estimate = ((marked + 1) * (captured + 1) / (recaptured + 1)) - 1
    variance = (
        (marked + 1)
        * (captured + 1)
        * (marked - recaptured)
        * (captured - recaptured)
        / ((recaptured + 1) ** 2 * (recaptured + 2))
    )
    standard_deviation = math.sqrt(max(0.0, variance))
    z = NormalDist().inv_cdf((1 + confidence) / 2)
    lower = max(float(max(marked, captured)), estimate - z * standard_deviation)
    upper = estimate + z * standard_deviation
    return CaptureRecaptureEstimate(
        float(estimate),
        float(standard_deviation),
        float(lower),
        float(upper),
        confidence,
        marked,
        captured,
        recaptured,
    )


def _mpc(value: Any, digits: int) -> mp.mpc:
    if isinstance(value, mp.mpc):
        return value
    if isinstance(value, complex):
        return mp.mpc(str(value.real), str(value.imag))
    expr = sp.sympify(value)
    return mp.mpc(
        str(sp.N(sp.re(expr), digits)),
        str(sp.N(sp.im(expr), digits)),
    )


def second_order_trace_test(
    equations: Sequence[Any],
    variables: Sequence[sp.Symbol],
    roots: Sequence[Sequence[Any]],
    *,
    direction: Sequence[Any] | None = None,
    digits: int = 50,
) -> float:
    """Return the normalized second-order trace residual for a root set.

    For the additive parameter family ``F(x) - s*r = 0``, implicit
    differentiation gives ``J x' = r`` and
    ``J x'' = -H_F[x', x']``. This is a family-specific curvature
    diagnostic, not a completeness test: complete nonlinear fibers may have
    nonzero curvature, and incomplete subsets may have zero curvature. The
    affine trace theorem for generic linear slices does not apply to arbitrary
    additive deformations. Singular roots yield ``inf``.
    """
    equations = tuple(sp.sympify(eq) for eq in equations)
    variables = tuple(variables)
    if not roots:
        return math.inf
    if len(equations) != len(variables):
        raise ValueError("trace test currently requires a square system")
    if any(len(root) != len(variables) for root in roots):
        raise ValueError("root dimension does not match variables")
    if direction is None:
        direction = tuple(1 + index for index in range(len(variables)))
    direction = tuple(direction)
    if len(direction) != len(equations):
        raise ValueError("trace direction dimension does not match equations")

    args = variables
    jacobian_expr = sp.Matrix(equations).jacobian(variables)
    hessians_expr = [sp.hessian(eq, variables) for eq in equations]
    jacobian_fn = sp.lambdify(args, jacobian_expr.tolist(), modules="mpmath")
    hessian_fns = [sp.lambdify(args, matrix.tolist(), modules="mpmath") for matrix in hessians_expr]

    with mp.workdps(digits + 12):
        rhs = mp.matrix([_mpc(value, digits + 8) for value in direction])
        trace = mp.matrix([mp.mpc(0) for _ in variables])
        scale = mp.mpf(1)
        for root in roots:
            values = tuple(_mpc(value, digits + 8) for value in root)
            jac_raw = jacobian_fn(*values)
            jac = mp.matrix([[mp.mpc(value) for value in row] for row in jac_raw])
            try:
                velocity = mp.lu_solve(jac, rhs)
            except (ZeroDivisionError, ValueError):
                return math.inf
            contraction = mp.matrix(len(equations), 1)
            for eq_index, hessian_fn in enumerate(hessian_fns):
                h_raw = hessian_fn(*values)
                hessian = mp.matrix([[mp.mpc(value) for value in row] for row in h_raw])
                contraction[eq_index] = (velocity.T * hessian * velocity)[0]
            try:
                acceleration = mp.lu_solve(jac, -contraction)
            except (ZeroDivisionError, ValueError):
                return math.inf
            trace += acceleration
            scale = max(
                scale,
                max((abs(acceleration[i]) for i in range(acceleration.rows)), default=mp.mpf(0)),
            )
        residual = max((abs(trace[i]) for i in range(trace.rows)), default=mp.mpf(0)) / scale
        return float(residual)
