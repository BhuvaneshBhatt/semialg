"""Compatibility helpers for the historical RUR quotient module.

The canonical quotient-algebra implementation now lives in :mod:`algroots.quotient`.
These private helpers remain so older internal imports keep working while all
algorithms share one implementation.
"""

from __future__ import annotations

from collections.abc import Iterable, Sequence

import sympy as sp
from sympy.polys.domains import Domain

from .. import quotient as _core
from ..quotient import QuotientAlgebra, QuotientAlgebraError
from .representation import RationalUnivariateError

_leading_exponent_grevlex = _core._leading_exponent_grevlex
_monomial_from_exponent = _core.monomial_from_exponent
_standard_exponent_count = _core.standard_exponent_count
_standard_exponents = _core.standard_exponents


def _translate(exc: QuotientAlgebraError) -> RationalUnivariateError:
    return RationalUnivariateError(str(exc))


def _exact_coefficient_domain(
    expressions: Iterable[sp.Expr], variables: Sequence[sp.Symbol]
) -> Domain:
    try:
        _, domain = _core._exact_polynomials(expressions, variables)
        return domain
    except QuotientAlgebraError as exc:
        raise _translate(exc) from exc


def _as_exact_polynomial(
    expr: sp.Expr,
    variables: Sequence[sp.Symbol],
    domain: Domain,
) -> sp.Poly:
    try:
        poly = sp.Poly(sp.expand(expr), *variables, domain=domain)
    except (
        sp.PolynomialError,
        sp.polys.polyerrors.CoercionFailed,
        ValueError,
        TypeError,
        NotImplementedError,
    ) as exc:
        raise RationalUnivariateError(
            "RUR requires polynomial equations over the inferred exact coefficient field"
        ) from exc
    if poly.total_degree() < 0:
        raise RationalUnivariateError("zero polynomial is not a valid defining equation")
    return poly


def _as_rational_polynomial(expr: sp.Expr, variables: Sequence[sp.Symbol]) -> sp.Poly:
    return _as_exact_polynomial(expr, variables, sp.QQ)


def _normal_form(groebner_basis: sp.polys.polytools.GroebnerBasis, expr: sp.Expr) -> sp.Expr:
    try:
        return _core._normal_form_for_basis(groebner_basis, expr)
    except QuotientAlgebraError as exc:
        raise _translate(exc) from exc


def _coefficient_vector(
    expr: sp.Expr,
    variables: Sequence[sp.Symbol],
    basis_exponents: Sequence[Sequence[int]],
    domain: Domain = sp.QQ,
) -> sp.Matrix:
    try:
        return _core._coefficient_vector(expr, variables, basis_exponents, domain)
    except QuotientAlgebraError as exc:
        raise _translate(exc) from exc


def _variable_multiplication_matrices(
    groebner_basis: sp.polys.polytools.GroebnerBasis,
    variables: Sequence[sp.Symbol],
    basis_exponents: Sequence[Sequence[int]],
    domain: Domain | None = None,
) -> tuple[sp.Matrix, ...]:
    try:
        quotient = QuotientAlgebra.from_groebner_basis(groebner_basis, variables)
    except QuotientAlgebraError as exc:
        raise _translate(exc) from exc
    if tuple(tuple(int(v) for v in exp) for exp in basis_exponents) != quotient.standard_exponents:
        raise RationalUnivariateError(
            "basis exponents do not match the canonical quotient staircase"
        )
    return quotient.variable_multiplication_matrices


def _select_separating_linear_form(
    groebner_basis: sp.polys.polytools.GroebnerBasis,
    variables: Sequence[sp.Symbol],
    parameter: sp.Symbol,
    basis_exponents: Sequence[Sequence[int]],
    basis_matrices: Sequence[sp.Matrix] | None = None,
    *,
    max_attempts: int = 64,
):
    del basis_matrices
    try:
        quotient = QuotientAlgebra.from_groebner_basis(groebner_basis, variables)
        if quotient.standard_exponents != tuple(tuple(int(v) for v in e) for e in basis_exponents):
            raise QuotientAlgebraError(
                "basis exponents do not match the canonical quotient staircase"
            )
        separator = quotient.separating_element(parameter, max_attempts=max_attempts)
    except QuotientAlgebraError as exc:
        raise _translate(exc) from exc
    return (
        separator.expression,
        separator.defining_polynomial,
        separator.coordinate_denominator,
        separator.trace_vector,
        list(separator.power_vectors),
        separator.geometric_solution_count,
    )


def _monic_polynomial(poly: sp.Poly) -> sp.Poly:
    if poly.is_zero:
        raise RationalUnivariateError("zero polynomial cannot be normalized to monic form")
    return poly.monic()


def _squarefree_part(poly: sp.Poly) -> sp.Poly:
    return poly.sqf_part().monic()
