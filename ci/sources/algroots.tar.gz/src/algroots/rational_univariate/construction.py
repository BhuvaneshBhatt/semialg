from __future__ import annotations

from collections.abc import Iterable, Sequence

import sympy as sp

from ..errors import QuotientAlgebraError
from ..quotient import QuotientAlgebra
from .representation import RationalUnivariateError, RationalUnivariateRepresentation


def _as_rur_error(exc: QuotientAlgebraError) -> RationalUnivariateError:
    return RationalUnivariateError(str(exc))


def compute_rational_univariate_representation(
    polynomials: Iterable[sp.Expr],
    variables: Sequence[sp.Symbol],
    parameter: sp.Symbol | None = None,
    *,
    max_separating_attempts: int = 64,
) -> RationalUnivariateRepresentation:
    """Compute an exact RUR for a zero-dimensional polynomial system.

    Coefficients may be rational numbers or exact algebraic numbers.  The
    equality-only quotient structure is provided by :class:`algroots.quotient.QuotientAlgebra`;
    this function adds the rational-univariate representation layer.
    """

    variable_tuple = tuple(variables)
    raw_polynomials = tuple(sp.sympify(poly) for poly in polynomials)
    if not variable_tuple:
        raise RationalUnivariateError("at least one variable is required")
    if len(raw_polynomials) < len(variable_tuple):
        raise RationalUnivariateError(
            "at least as many equations as variables are required for rational univariate solving"
        )
    if parameter is None:
        used_names = {str(symbol) for symbol in variable_tuple}
        name = "_rur_t"
        while name in used_names:
            name = "_" + name
        parameter = sp.Symbol(name)
    if parameter in variable_tuple:
        raise RationalUnivariateError("parameter must be distinct from system variables")

    try:
        quotient = QuotientAlgebra.from_polynomials(
            raw_polynomials, variable_tuple, order="grevlex"
        )
    except QuotientAlgebraError as exc:
        raise _as_rur_error(exc) from exc
    return rur_from_quotient(quotient, parameter, max_separating_attempts=max_separating_attempts)


def rur_from_quotient(quotient, parameter=None, *, max_separating_attempts=64):
    """Build an RUR of precisely the supplied algebra without rebuilding its ideal."""
    variable_tuple = quotient.variables
    if parameter is None:
        name = "_rur_t"
        while name in {str(v) for v in variable_tuple}:
            name = "_" + name
        parameter = sp.Symbol(name)
    if parameter in variable_tuple:
        raise RationalUnivariateError("parameter must be distinct from system variables")
    domain = quotient.domain
    if quotient.dimension == 0:
        return RationalUnivariateRepresentation(
            variables=variable_tuple,
            parameter=parameter,
            defining_polynomial=sp.Poly(1, parameter, domain=domain),
            coordinate_denominator=sp.Poly(1, parameter, domain=domain),
            coordinate_numerators=tuple(
                sp.Poly(0, parameter, domain=domain) for _ in variable_tuple
            ),
            separating_linear_form=sp.Integer(0),
            standard_exponents=tuple(),
            quotient_dimension=0,
            geometric_solution_count=0,
        )

    try:
        separator = quotient.separating_element(
            parameter,
            max_attempts=max_separating_attempts,
        )
    except QuotientAlgebraError as exc:
        raise _as_rur_error(exc) from exc

    defining_poly = separator.defining_polynomial
    degree = defining_poly.degree()
    coeffs_ascending = list(reversed(defining_poly.all_coeffs()))
    horner_vectors: list[sp.Matrix] = []
    for power_index in range(degree):
        vector = sp.zeros(quotient.dimension, 1)
        for shift in range(power_index + 1):
            coeff = coeffs_ascending[degree - shift]
            vector += coeff * separator.power_vectors[power_index - shift]
        horner_vectors.append(sp.simplify(vector))

    coordinate_numerators: list[sp.Poly] = []
    for variable_mult in quotient.variable_multiplication_matrices:
        trace_variable_products = variable_mult.T * separator.trace_vector
        numerator = sp.Integer(0)
        for power_index, horner_vector in enumerate(horner_vectors):
            numerator += (horner_vector.T * trace_variable_products)[0] * parameter ** (
                degree - power_index - 1
            )
        coordinate_numerators.append(sp.Poly(sp.expand(numerator), parameter, domain=domain))

    return RationalUnivariateRepresentation(
        variables=variable_tuple,
        parameter=parameter,
        defining_polynomial=defining_poly,
        coordinate_denominator=separator.coordinate_denominator,
        coordinate_numerators=tuple(coordinate_numerators),
        separating_linear_form=separator.expression,
        standard_exponents=quotient.standard_exponents,
        quotient_dimension=quotient.dimension,
        geometric_solution_count=separator.geometric_solution_count,
    )
