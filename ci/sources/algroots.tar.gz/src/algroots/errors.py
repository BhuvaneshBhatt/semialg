"""Public exception types for algroots solvers."""


class PolynomialSystemError(ValueError):
    """Base class for polynomial-system solver errors."""


class PolynomialSystemInputError(PolynomialSystemError):
    """The supplied equations or variables are outside the supported domain."""


class QuotientAlgebraError(PolynomialSystemError):
    """An exact finite quotient algebra could not be constructed."""


class NotZeroDimensionalError(PolynomialSystemError):
    """The polynomial system does not have a zero-dimensional solution set."""


class ShapePositionError(PolynomialSystemError):
    """The lexicographic Gröbner basis is not in supported shape position."""


class ActionMatrixError(PolynomialSystemError):
    """The quotient-algebra action-matrix backend could not certify all roots."""


class TriangularSolveError(PolynomialSystemError):
    """The system could not be resolved by triangular back-substitution."""


class HomotopySolveError(PolynomialSystemError):
    """The total-degree homotopy backend could not track all required paths."""


class NumericalRootError(PolynomialSystemError):
    """Numerical root computation or residual verification failed."""


class RootMultiplicityError(PolynomialSystemError):
    """Local multiplicities needed for the requested root view are unavailable."""


class RootOrderingError(PolynomialSystemError):
    """The requested exact coordinate order could not be established."""


class SystemSolveLimitError(PolynomialSystemError):
    """A solver safety limit was exceeded."""


_SPECIALIZED_ERRORS = {
    "ExactCertificationError": "recognition",
    "RootCertificationError": "certification",
    "RationalUnivariateError": "rational_univariate",
    "BorderBasisError": "border_basis",
    "PathTrackingError": "continuation",
    "PathStepError": "continuation",
}


def __getattr__(name):
    """Resolve specialized exception aliases without import cycles."""
    from importlib import import_module

    if name not in _SPECIALIZED_ERRORS:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    value = getattr(import_module(f".{_SPECIALIZED_ERRORS[name]}", __package__), name)
    globals()[name] = value
    return value


__all__ = [
    "PolynomialSystemError",
    "PolynomialSystemInputError",
    "QuotientAlgebraError",
    "NotZeroDimensionalError",
    "ShapePositionError",
    "ActionMatrixError",
    "TriangularSolveError",
    "HomotopySolveError",
    "NumericalRootError",
    "SystemSolveLimitError",
    "RootMultiplicityError",
    "RootOrderingError",
    *_SPECIALIZED_ERRORS,
]
